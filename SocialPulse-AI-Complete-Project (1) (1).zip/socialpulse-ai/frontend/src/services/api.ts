import type {
  FilterState,
  DashboardSummaryResponse,
  PostsResponse,
  PostDetailBenchmark,
  PredictionInput,
  PredictionResponse,
  ModelMetricsResponse,
  DataQualityReport,
  InsightItem,
  DatasetInfo,
} from '../types';

const API_BASE = '/api';

function buildQueryString(params: Record<string, any>): string {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, val]) => {
    if (val !== undefined && val !== null && val !== '' && val !== 'all') {
      query.append(key, String(val));
    }
  });
  const qs = query.toString();
  return qs ? `?${qs}` : '';
}

export const api = {
  async getHealth(): Promise<{ status: string; app: string; active_dataset: string; total_rows: number }> {
    const res = await fetch(`${API_BASE}/health`);
    if (!res.ok) throw new Error('Health check failed');
    return res.json();
  },

  async getDatasetInfo(): Promise<DatasetInfo> {
    const res = await fetch(`${API_BASE}/dataset-info`);
    if (!res.ok) throw new Error('Failed to fetch dataset metadata');
    return res.json();
  },

  async getSummary(filters: FilterState): Promise<DashboardSummaryResponse> {
    const qs = buildQueryString({
      platform: filters.platform,
      post_type: filters.post_type,
      sentiment: filters.sentiment,
      start_date: filters.start_date,
      end_date: filters.end_date,
      search: filters.search,
      exclude_outliers: filters.exclude_outliers,
    });
    const res = await fetch(`${API_BASE}/summary${qs}`);
    if (!res.ok) throw new Error('Failed to fetch summary data');
    return res.json();
  },

  async getPosts(
    page: number = 1,
    pageSize: number = 15,
    sortBy: string = 'Date',
    sortDesc: boolean = true,
    filters: FilterState
  ): Promise<PostsResponse> {
    const qs = buildQueryString({
      page,
      page_size: pageSize,
      sort_by: sortBy,
      sort_desc: sortDesc,
      platform: filters.platform,
      post_type: filters.post_type,
      sentiment: filters.sentiment,
      start_date: filters.start_date,
      end_date: filters.end_date,
      search: filters.search,
      exclude_outliers: filters.exclude_outliers,
    });
    const res = await fetch(`${API_BASE}/posts${qs}`);
    if (!res.ok) throw new Error('Failed to fetch posts');
    return res.json();
  },

  async getPostDetail(postId: string): Promise<PostDetailBenchmark> {
    const res = await fetch(`${API_BASE}/posts/${encodeURIComponent(postId)}`);
    if (!res.ok) throw new Error(`Post ${postId} not found`);
    return res.json();
  },

  async getPlatformComparison(filters: FilterState): Promise<{
    platforms: any[];
    total_posts: number;
    summary_notes: string[];
  }> {
    const qs = buildQueryString({
      post_type: filters.post_type,
      sentiment: filters.sentiment,
      start_date: filters.start_date,
      end_date: filters.end_date,
      exclude_outliers: filters.exclude_outliers,
    });
    const res = await fetch(`${API_BASE}/platform-comparison${qs}`);
    if (!res.ok) throw new Error('Failed to fetch platform comparison');
    return res.json();
  },

  async getInsights(filters: FilterState): Promise<{
    insights: InsightItem[];
    sample_size: number;
    disclaimer: string;
  }> {
    const qs = buildQueryString({
      platform: filters.platform,
      post_type: filters.post_type,
      sentiment: filters.sentiment,
      start_date: filters.start_date,
      end_date: filters.end_date,
      exclude_outliers: filters.exclude_outliers,
    });
    const res = await fetch(`${API_BASE}/insights${qs}`);
    if (!res.ok) throw new Error('Failed to fetch insights');
    return res.json();
  },

  async getDataQuality(): Promise<DataQualityReport> {
    const res = await fetch(`${API_BASE}/data-quality`);
    if (!res.ok) throw new Error('Failed to fetch data quality report');
    return res.json();
  },

  async getModelMetrics(): Promise<ModelMetricsResponse> {
    const res = await fetch(`${API_BASE}/model-metrics`);
    if (!res.ok) throw new Error('Failed to fetch model metrics');
    return res.json();
  },

  async predict(input: PredictionInput): Promise<PredictionResponse> {
    const res = await fetch(`${API_BASE}/predict`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Prediction failed' }));
      throw new Error(err.detail || 'Prediction failed');
    }
    return res.json();
  },

  async uploadDataset(file: File): Promise<{
    success: boolean;
    message: string;
    total_records: number;
    active_dataset: string;
  }> {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`${API_BASE}/upload`, {
      method: 'POST',
      body: formData,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Upload failed' }));
      throw new Error(err.detail || 'Upload failed');
    }
    return res.json();
  },

  async resetDataset(): Promise<{ success: boolean; message: string; active_dataset: string }> {
    const res = await fetch(`${API_BASE}/reset`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to reset dataset');
    return res.json();
  },

  getExportCsvUrl(filters: FilterState): string {
    const qs = buildQueryString({
      platform: filters.platform,
      post_type: filters.post_type,
      sentiment: filters.sentiment,
      start_date: filters.start_date,
      end_date: filters.end_date,
      search: filters.search,
      exclude_outliers: filters.exclude_outliers,
    });
    return `${API_BASE}/export/csv${qs}`;
  },

  getExportCleanedUrl(): string {
    return `${API_BASE}/export/cleaned`;
  },

  getExportOriginalUrl(): string {
    return `${API_BASE}/export/original`;
  },

  getExportPdfUrl(filters: FilterState): string {
    const qs = buildQueryString({
      platform: filters.platform,
      post_type: filters.post_type,
      sentiment: filters.sentiment,
      start_date: filters.start_date,
      end_date: filters.end_date,
      exclude_outliers: filters.exclude_outliers,
    });
    return `${API_BASE}/export/pdf${qs}`;
  },
};
