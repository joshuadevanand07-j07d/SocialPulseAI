import React from 'react';
import { HelpCircle } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
  trend?: {
    value: string;
    isPositive?: boolean;
  };
  tooltip?: string;
  accentColor?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  trend,
  tooltip,
  accentColor = 'border-slate-800',
}) => {
  return (
    <div className={`p-4 rounded-xl bg-[#111827] border ${accentColor} shadow-md transition-all hover:border-slate-700`}>
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-1.5 text-xs text-slate-400 font-medium">
          <span>{title}</span>
          {tooltip && (
            <span title={tooltip} className="cursor-help text-slate-500 hover:text-slate-300">
              <HelpCircle className="w-3.5 h-3.5" />
            </span>
          )}
        </div>
        {icon && (
          <div className="p-2 rounded-lg bg-[#162035] text-slate-300 border border-[#263554]">
            {icon}
          </div>
        )}
      </div>

      <div className="mt-2.5">
        <div className="text-xl md:text-2xl font-bold tracking-tight text-white">{value}</div>
        {(subtitle || trend) && (
          <div className="mt-1 flex items-center space-x-2 text-xs text-slate-400">
            {trend && (
              <span
                className={`font-semibold ${
                  trend.isPositive ? 'text-emerald-400' : 'text-slate-400'
                }`}
              >
                {trend.value}
              </span>
            )}
            {subtitle && <span className="truncate">{subtitle}</span>}
          </div>
        )}
      </div>
    </div>
  );
};
