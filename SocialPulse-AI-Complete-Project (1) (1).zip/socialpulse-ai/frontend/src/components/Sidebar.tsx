import React from 'react';
import {
  LayoutDashboard,
  Table2,
  BarChart3,
  Sparkles,
  BrainCircuit,
  Lightbulb,
  ShieldCheck,
  FileDown,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Radio,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'explorer'
  | 'comparison'
  | 'performance'
  | 'prediction'
  | 'insights'
  | 'quality'
  | 'downloads'
  | 'about';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  collapsed: boolean;
  onToggleCollapsed: () => void;
  totalRecords: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  collapsed,
  onToggleCollapsed,
  totalRecords,
}) => {
  const navItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    {
      id: 'dashboard',
      label: 'Overview Dashboard',
      icon: <LayoutDashboard className="w-5 h-5" />,
    },
    {
      id: 'explorer',
      label: 'Data Explorer',
      icon: <Table2 className="w-5 h-5" />,
      badge: `${totalRecords}`,
    },
    {
      id: 'comparison',
      label: 'Platform Comparison',
      icon: <BarChart3 className="w-5 h-5" />,
    },
    {
      id: 'performance',
      label: 'Post Deep-Dive',
      icon: <Sparkles className="w-5 h-5" />,
    },
    {
      id: 'prediction',
      label: 'ML Engagement Predictor',
      icon: <BrainCircuit className="w-5 h-5 text-violet-400" />,
      badge: 'ML',
    },
    {
      id: 'insights',
      label: 'Insights & Recommendations',
      icon: <Lightbulb className="w-5 h-5" />,
    },
    {
      id: 'quality',
      label: 'Data Quality & Audit',
      icon: <ShieldCheck className="w-5 h-5" />,
    },
    {
      id: 'downloads',
      label: 'Downloads & PDF Reports',
      icon: <FileDown className="w-5 h-5" />,
    },
    {
      id: 'about',
      label: 'About & Methodology',
      icon: <BookOpen className="w-5 h-5" />,
    },
  ];

  return (
    <aside
      className={`relative flex flex-col border-r transition-all duration-300 ease-in-out shrink-0 ${
        collapsed ? 'w-20' : 'w-64'
      } bg-[#0e1424] border-[#1e293b] text-slate-300`}
    >
      {/* Brand Logo Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-[#1e293b]">
        {!collapsed && (
          <div className="flex items-center space-x-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-violet-600 via-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-violet-500/20">
              <Radio className="w-4 h-4 text-white animate-pulse" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-sm tracking-wide bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                SocialPulse AI
              </span>
              <span className="text-[10px] text-violet-400 font-medium tracking-wider uppercase">
                Analytics & ML
              </span>
            </div>
          </div>
        )}
        {collapsed && (
          <div className="mx-auto w-8 h-8 rounded-lg bg-gradient-to-tr from-violet-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-violet-500/20">
            <Radio className="w-4 h-4 text-white" />
          </div>
        )}
        <button
          onClick={onToggleCollapsed}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className="hidden md:flex items-center justify-center w-7 h-7 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
                isActive
                  ? 'bg-gradient-to-r from-violet-600/20 to-indigo-600/10 text-violet-300 border border-violet-500/30 shadow-sm'
                  : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-transparent'
              }`}
              title={collapsed ? item.label : undefined}
            >
              <span className={`shrink-0 ${isActive ? 'text-violet-400' : 'text-slate-400 group-hover:text-slate-200'}`}>
                {item.icon}
              </span>
              {!collapsed && (
                <div className="flex items-center justify-between flex-1 ml-3 text-left">
                  <span className="truncate">{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wider ${
                        item.badge === 'ML'
                          ? 'bg-violet-950/80 text-violet-300 border border-violet-500/40'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Sidebar Footer info */}
      {!collapsed && (
        <div className="p-3 m-3 rounded-lg bg-[#141b2e] border border-[#222e47] text-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-medium">Dataset Status</span>
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>
          <p className="text-[11px] text-slate-300 font-medium truncate">
            {totalRecords} Posts Verified
          </p>
          <p className="text-[10px] text-slate-400 mt-0.5">
            100% Observed Historical Data
          </p>
        </div>
      )}
    </aside>
  );
};
