import React, { useState, useRef } from 'react';
import {
  X,
  UploadCloud,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  FileCheck,
} from 'lucide-react';
import { api } from '../services/api';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (activeDataset: string, count: number) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
      setSuccessMsg(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
      setError(null);
      setSuccessMsg(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Please select an Excel (.xlsx, .xls) or CSV (.csv) file.');
      return;
    }

    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await api.uploadDataset(file);
      setSuccessMsg(res.message);
      onUploadSuccess(res.active_dataset, res.total_records);
      setTimeout(() => {
        onClose();
        setFile(null);
        setSuccessMsg(null);
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Upload failed. Please check required columns and format.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#111827] border border-[#263554] shadow-2xl p-6 text-slate-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={loading}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
            <UploadCloud className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-white">Upload New Dataset</h3>
            <p className="text-xs text-slate-400">
              Replace current active session data (.xlsx or .csv)
            </p>
          </div>
        </div>

        {/* Drag and Drop Box */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition-all ${
            isDragging
              ? 'border-violet-500 bg-violet-950/20'
              : 'border-[#263554] bg-[#162035]/60 hover:bg-[#162035] hover:border-slate-600'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".xlsx,.xls,.csv"
            className="hidden"
          />

          {file ? (
            <div className="flex items-center space-x-3 text-slate-200">
              <FileCheck className="w-8 h-8 text-emerald-400" />
              <div className="text-left">
                <p className="text-sm font-medium text-white truncate max-w-xs">{file.name}</p>
                <p className="text-xs text-slate-400">{(file.size / 1024).toFixed(1)} KB</p>
              </div>
            </div>
          ) : (
            <>
              <FileSpreadsheet className="w-10 h-10 text-slate-500 mb-2" />
              <p className="text-sm font-medium text-slate-300">
                Click or drag & drop your file here
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Supports Excel (.xlsx, .xls) and CSV (up to 15MB)
              </p>
            </>
          )}
        </div>

        {/* Schema Requirement Notice */}
        <div className="mt-4 p-3 rounded-lg bg-[#162035] border border-[#263554] text-xs space-y-1.5">
          <p className="font-semibold text-slate-300 flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400 mr-2" />
            Required Columns Check:
          </p>
          <p className="text-[11px] text-slate-400 leading-relaxed font-mono">
            Post_ID, Platform, Post_Type, Date, Followers, Impressions, Reach, Likes, Comments, Shares, Saves, Video_Views, CTR_%, Engagement_Rate_%, Sentiment, Hashtag_Count
          </p>
          <p className="text-[10px] text-slate-500 italic">
            Note: Uploaded files update the current analysis and model in-memory. The original workbook on disk remains unaltered.
          </p>
        </div>

        {/* Feedback Messages */}
        {error && (
          <div className="mt-3 p-3 rounded-lg bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="mt-3 p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Modal Actions */}
        <div className="mt-6 flex items-center justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 text-xs font-medium rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!file || loading}
            className="flex items-center space-x-2 px-5 py-2 text-xs font-semibold rounded-lg bg-violet-600 hover:bg-violet-500 text-white disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-violet-600/20 transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <span>Upload & Validate</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
