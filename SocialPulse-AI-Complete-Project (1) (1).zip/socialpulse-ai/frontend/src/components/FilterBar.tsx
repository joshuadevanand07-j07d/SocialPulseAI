import React from 'react';
import {
  Filter,
  Search,
  X,
  ShieldAlert,
  Calendar,
  Layers,
  Smile,
  Globe,
} from 'lucide-react';
import { FilterState } from '../types';

interface FilterBarProps {
  filters: FilterState;
  onChangeFilters: (updated: Partial<FilterState>) => void;
  onResetFilters: () => void;
  filteredCount: number;
  totalCount: number;
  platforms: string[];
  postTypes: string[];
  sentiments: string[];
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onChangeFilters,
  onResetFilters,
  filteredCount,
  totalCount,
  platforms,
  postTypes,
  sentiments,
}) => {
  const isFiltered =
    filters.platform !== 'all' ||
    filters.post_type !== 'all' ||
    filters.sentiment !== 'all' ||
    Boolean(filters.start_date) ||
    Boolean(filters.end_date) ||
    Boolean(filters.search) ||
    filters.exclude_outliers;

  return (
    <div className="bg-[#111827] border-b border-[#1e293b] p-3 md:px-6 md:py-3.5 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Search input */}
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by Post ID, platform, type..."
            value={filters.search}
            onChange={(e) => onChangeFilters({ search: e.target.value })}
            className="w-full pl-9 pr-8 py-1.5 text-xs md:text-sm rounded-lg bg-[#162035] border border-[#263554] text-slate-200 placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors"
          />
          {filters.search && (
            <button
              onClick={() => onChangeFilters({ search: '' })}
              className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Outlier Filter Toggle */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onChangeFilters({ exclude_outliers: !filters.exclude_outliers })}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
              filters.exclude_outliers
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/10'
                : 'bg-[#162035] text-slate-400 border-[#263554] hover:text-slate-200 hover:bg-slate-800'
            }`}
            title="Exclude high ER outliers (>100% where interactions surpass recorded reach) for robust analysis"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>Robust View {filters.exclude_outliers ? '(Outliers Hidden)' : '(Raw Data)'}</span>
          </button>

          {/* Reset Filters button */}
          {isFiltered && (
            <button
              onClick={onResetFilters}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 border border-rose-500/30 transition-colors"
              title="Clear all active filters"
            >
              <X className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}

          {/* Active Record Match Counter */}
          <div className="px-2.5 py-1.5 rounded-lg bg-[#162035] border border-[#263554] text-xs font-medium text-slate-300">
            <span className="text-violet-400 font-bold">{filteredCount}</span>
            <span className="text-slate-500"> / {totalCount} records</span>
          </div>
        </div>
      </div>

      {/* Dropdown Filters row */}
      <div className="flex flex-wrap items-center gap-2 pt-1">
        {/* Platform Filter */}
        <div className="flex items-center space-x-1 text-xs">
          <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={filters.platform}
            onChange={(e) => onChangeFilters({ platform: e.target.value })}
            className="px-2.5 py-1 rounded-md bg-[#162035] border border-[#263554] text-slate-200 text-xs focus:outline-none focus:border-violet-500"
          >
            <option value="all">All Platforms</option>
            {platforms.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>

        {/* Post Type Filter */}
        <div className="flex items-center space-x-1 text-xs">
          <Layers className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={filters.post_type}
            onChange={(e) => onChangeFilters({ post_type: e.target.value })}
            className="px-2.5 py-1 rounded-md bg-[#162035] border border-[#263554] text-slate-200 text-xs focus:outline-none focus:border-violet-500"
          >
            <option value="all">All Post Types</option>
            {postTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Sentiment Filter */}
        <div className="flex items-center space-x-1 text-xs">
          <Smile className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={filters.sentiment}
            onChange={(e) => onChangeFilters({ sentiment: e.target.value })}
            className="px-2.5 py-1 rounded-md bg-[#162035] border border-[#263554] text-slate-200 text-xs focus:outline-none focus:border-violet-500"
          >
            <option value="all">All Sentiments</option>
            {sentiments.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Date Range Start */}
        <div className="flex items-center space-x-1 text-xs">
          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <input
            type="date"
            value={filters.start_date}
            onChange={(e) => onChangeFilters({ start_date: e.target.value })}
            className="px-2 py-1 rounded-md bg-[#162035] border border-[#263554] text-slate-200 text-xs focus:outline-none focus:border-violet-500"
            title="Start date"
          />
          <span className="text-slate-500">to</span>
          <input
            type="date"
            value={filters.end_date}
            onChange={(e) => onChangeFilters({ end_date: e.target.value })}
            className="px-2 py-1 rounded-md bg-[#162035] border border-[#263554] text-slate-200 text-xs focus:outline-none focus:border-violet-500"
            title="End date"
          />
        </div>
      </div>
    </div>
  );
};
