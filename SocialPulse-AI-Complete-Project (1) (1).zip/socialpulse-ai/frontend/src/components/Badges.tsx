import React from 'react';

export const PlatformBadge: React.FC<{ platform: string }> = ({ platform }) => {
  const p = platform.toLowerCase();
  let bg = 'bg-slate-800 text-slate-300 border-slate-700';

  if (p.includes('facebook')) {
    bg = 'bg-blue-950/70 text-blue-300 border-blue-500/40';
  } else if (p.includes('instagram')) {
    bg = 'bg-pink-950/70 text-pink-300 border-pink-500/40';
  } else if (p.includes('linkedin')) {
    bg = 'bg-sky-950/70 text-sky-300 border-sky-500/40';
  } else if (p === 'x' || p.includes('twitter')) {
    bg = 'bg-slate-900 text-slate-200 border-slate-600';
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold border ${bg}`}>
      {platform}
    </span>
  );
};

export const SentimentBadge: React.FC<{ sentiment: string }> = ({ sentiment }) => {
  const s = sentiment.toLowerCase();
  let bg = 'bg-slate-800 text-slate-300 border-slate-700';

  if (s === 'positive') {
    bg = 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40';
  } else if (s === 'negative') {
    bg = 'bg-rose-950/70 text-rose-300 border-rose-500/40';
  } else if (s === 'neutral') {
    bg = 'bg-amber-950/70 text-amber-300 border-amber-500/40';
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium border ${bg}`}>
      {sentiment}
    </span>
  );
};

export const OutlierBadge: React.FC<{ isOutlier: boolean; reason?: string }> = ({
  isOutlier,
  reason,
}) => {
  if (!isOutlier) return null;

  return (
    <span
      className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-950/60 text-amber-300 border border-amber-500/40 cursor-help"
      title={reason || 'Extreme Engagement Rate outlier'}
    >
      Anomaly
    </span>
  );
};
