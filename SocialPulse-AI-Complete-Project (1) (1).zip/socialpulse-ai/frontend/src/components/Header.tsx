import React from 'react';
import {
  Upload,
  RotateCcw,
  FileText,
  Sun,
  Moon,
  Database,
  Menu,
} from 'lucide-react';
import { DatasetInfo } from '../types';

interface HeaderProps {
  datasetInfo: DatasetInfo | null;
  onOpenUpload: () => void;
  onResetDataset: () => void;
  onOpenReport: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onToggleMobileSidebar: () => void;
  isResetting: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  datasetInfo,
  onOpenUpload,
  onResetDataset,
  onOpenReport,
  isDarkMode,
  onToggleTheme,
  onToggleMobileSidebar,
  isResetting,
}) => {
  return (
    <header className="h-16 border-b border-[#1e293b] bg-[#0e1424] px-4 md:px-6 flex items-center justify-between shrink-0">
      {/* Left: Mobile Toggle & Active Dataset Indicator */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onToggleMobileSidebar}
          className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 focus:outline-none"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-2.5">
          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-[#162035] border border-[#263554] text-xs">
            <Database className="w-3.5 h-3.5 text-violet-400 shrink-0" />
            <span className="text-slate-400 hidden sm:inline">Active Dataset:</span>
            <span className="font-semibold text-slate-200 truncate max-w-[170px] md:max-w-[280px]" title={datasetInfo?.active_dataset_name}>
              {datasetInfo?.active_dataset_name || 'Loading dataset...'}
            </span>
            <span className="px-1.5 py-0.2 text-[10px] bg-violet-950/80 text-violet-300 font-semibold rounded border border-violet-500/30">
              {datasetInfo?.total_records || 300} rows
            </span>
          </div>

          {datasetInfo?.is_custom_dataset && (
            <button
              onClick={onResetDataset}
              disabled={isResetting}
              className="flex items-center space-x-1 px-2.5 py-1 text-xs rounded-md bg-amber-950/40 text-amber-300 border border-amber-500/40 hover:bg-amber-900/40 transition-colors"
              title="Reset to default initial 300-record dataset"
            >
              <RotateCcw className={`w-3 h-3 ${isResetting ? 'animate-spin' : ''}`} />
              <span className="hidden md:inline">Reset to Default</span>
            </button>
          )}
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center space-x-2 md:space-x-3">
        {/* Upload Button */}
        <button
          onClick={onOpenUpload}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium bg-[#1e293b] text-slate-200 hover:bg-slate-700/80 hover:text-white border border-slate-700 transition-colors shadow-sm"
        >
          <Upload className="w-4 h-4 text-cyan-400" />
          <span className="hidden sm:inline">Upload Dataset</span>
          <span className="sm:hidden">Upload</span>
        </button>

        {/* Generate PDF Report Button */}
        <button
          onClick={onOpenReport}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-sm shadow-violet-500/20 transition-all"
        >
          <FileText className="w-4 h-4" />
          <span className="hidden sm:inline">PDF Report</span>
          <span className="sm:hidden">Report</span>
        </button>

        {/* Theme Toggle */}
        <button
          onClick={onToggleTheme}
          title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          className="p-2 rounded-lg bg-[#162035] text-slate-300 hover:text-white border border-[#263554] hover:bg-slate-800 transition-colors"
        >
          {isDarkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-violet-400" />}
        </button>
      </div>
    </header>
  );
};
