import React, { useState, useEffect } from 'react';
import { Sidebar, NavTab } from './components/Sidebar';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { UploadModal } from './components/UploadModal';
import { DashboardPage } from './pages/DashboardPage';
import { DataExplorerPage } from './pages/DataExplorerPage';
import { PlatformComparisonPage } from './pages/PlatformComparisonPage';
import { PostPerformancePage } from './pages/PostPerformancePage';
import { PredictionPage } from './pages/PredictionPage';
import { InsightsPage } from './pages/InsightsPage';
import { DataQualityPage } from './pages/DataQualityPage';
import { DownloadsPage } from './pages/DownloadsPage';
import { AboutPage } from './pages/AboutPage';

import { FilterState, DashboardSummaryResponse, DatasetInfo } from './types';
import { api } from './services/api';

const initialFilters: FilterState = {
  platform: 'all',
  post_type: 'all',
  sentiment: 'all',
  start_date: '',
  end_date: '',
  search: '',
  exclude_outliers: false,
};

export const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [selectedPostId, setSelectedPostId] = useState<string>('P001');
  const [filters, setFilters] = useState<FilterState>(initialFilters);
  const [datasetInfo, setDatasetInfo] = useState<DatasetInfo | null>(null);
  const [summary, setSummary] = useState<DashboardSummaryResponse | null>(null);
  const [loadingSummary, setLoadingSummary] = useState<boolean>(true);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);

  // Fetch Dataset info once
  const loadDatasetMetadata = async () => {
    try {
      const info = await api.getDatasetInfo();
      setDatasetInfo(info);
    } catch (err) {
      console.error('Error fetching dataset metadata:', err);
    }
  };

  // Fetch Summary data when filters change
  const loadSummaryData = async () => {
    setLoadingSummary(true);
    try {
      const data = await api.getSummary(filters);
      setSummary(data);
    } catch (err) {
      console.error('Error fetching summary:', err);
    } finally {
      setLoadingSummary(false);
    }
  };

  useEffect(() => {
    loadDatasetMetadata();
  }, []);

  useEffect(() => {
    loadSummaryData();
  }, [filters]);

  const handleSelectPostFromTable = (postId: string) => {
    setSelectedPostId(postId);
    setCurrentTab('performance');
  };

  const handleResetDataset = async () => {
    setIsResetting(true);
    try {
      await api.resetDataset();
      await loadDatasetMetadata();
      await loadSummaryData();
    } catch (err) {
      console.error(err);
    } finally {
      setIsResetting(false);
    }
  };

  const handleUploadSuccess = async () => {
    await loadDatasetMetadata();
    await loadSummaryData();
  };

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    if (!isDarkMode) {
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.add('light');
    }
  };

  return (
    <div className={`min-h-screen flex bg-[#0b0f19] text-slate-100 ${isDarkMode ? 'dark' : 'light'}`}>
      {/* Desktop & Mobile Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          setMobileSidebarOpen(false);
        }}
        collapsed={sidebarCollapsed}
        onToggleCollapsed={() => setSidebarCollapsed(!sidebarCollapsed)}
        totalRecords={datasetInfo?.total_records || 300}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <Header
          datasetInfo={datasetInfo}
          onOpenUpload={() => setIsUploadOpen(true)}
          onResetDataset={handleResetDataset}
          onOpenReport={() => setCurrentTab('downloads')}
          isDarkMode={isDarkMode}
          onToggleTheme={toggleTheme}
          onToggleMobileSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          isResetting={isResetting}
        />

        {/* Global Filter Bar (visible across analytical tabs) */}
        {['dashboard', 'explorer', 'comparison', 'insights'].includes(currentTab) && (
          <FilterBar
            filters={filters}
            onChangeFilters={(updated) => setFilters((prev) => ({ ...prev, ...updated }))}
            onResetFilters={() => setFilters(initialFilters)}
            filteredCount={summary?.kpis.total_posts || 0}
            totalCount={datasetInfo?.total_records || 300}
            platforms={datasetInfo?.platforms || ['Facebook', 'Instagram', 'LinkedIn', 'X']}
            postTypes={datasetInfo?.post_types || ['Carousel', 'Image', 'Reel', 'Video', 'Text']}
            sentiments={datasetInfo?.sentiments || ['Negative', 'Neutral', 'Positive']}
          />
        )}

        {/* Dynamic Page Views */}
        <main className="flex-1 overflow-y-auto">
          {currentTab === 'dashboard' && (
            <DashboardPage
              summary={summary}
              loading={loadingSummary}
              onSelectPost={handleSelectPostFromTable}
            />
          )}

          {currentTab === 'explorer' && (
            <DataExplorerPage
              filters={filters}
              onSelectPost={handleSelectPostFromTable}
              onOpenUpload={() => setIsUploadOpen(true)}
            />
          )}

          {currentTab === 'comparison' && (
            <PlatformComparisonPage filters={filters} />
          )}

          {currentTab === 'performance' && (
            <PostPerformancePage
              selectedPostId={selectedPostId}
              onSelectPostId={(id) => setSelectedPostId(id)}
            />
          )}

          {currentTab === 'prediction' && (
            <PredictionPage
              platforms={datasetInfo?.platforms || ['Facebook', 'Instagram', 'LinkedIn', 'X']}
              postTypes={datasetInfo?.post_types || ['Carousel', 'Image', 'Reel', 'Video', 'Text']}
              sentiments={datasetInfo?.sentiments || ['Negative', 'Neutral', 'Positive']}
            />
          )}

          {currentTab === 'insights' && (
            <InsightsPage filters={filters} />
          )}

          {currentTab === 'quality' && (
            <DataQualityPage />
          )}

          {currentTab === 'downloads' && (
            <DownloadsPage filters={filters} summary={summary} />
          )}

          {currentTab === 'about' && (
            <AboutPage />
          )}
        </main>
      </div>

      {/* Dataset Upload Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={handleUploadSuccess}
      />
    </div>
  );
};
export default App;
