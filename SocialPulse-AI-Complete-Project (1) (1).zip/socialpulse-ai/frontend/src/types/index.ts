export interface PostRecord {
  Post_ID: string;
  Platform: string;
  Post_Type: string;
  Date: string;
  Followers: number;
  Impressions: number;
  Reach: number;
  Likes: number;
  Comments: number;
  Shares: number;
  Saves: number;
  Video_Views: number;
  "CTR_%": number;
  "Engagement_Rate_%": number;
  Sentiment: string;
  Hashtag_Count: number;
  Total_Interactions: number;
  Is_Outlier: boolean;
  Outlier_Reason?: string;
}

export interface FilterState {
  platform: string;
  post_type: string;
  sentiment: string;
  start_date: string;
  end_date: string;
  search: string;
  exclude_outliers: boolean;
}

export interface KPISummary {
  total_posts: number;
  total_likes: number;
  total_comments: number;
  total_shares: number;
  total_saves: number;
  total_interactions: number;
  total_impressions: number;
  total_reach: number;
  total_video_views: number;
  avg_engagement_rate: number;
  median_engagement_rate: number;
  avg_ctr: number;
  median_ctr: number;
  platform_count: number;
  active_dataset_name: string;
  is_custom_dataset: boolean;
  total_dataset_rows: number;
  filtered_rows_count: number;
  outlier_count: number;
}

export interface PlatformStat {
  platform: string;
  post_count: number;
  post_share_pct: number;
  avg_engagement_rate: number;
  median_engagement_rate: number;
  avg_ctr: number;
  median_ctr: number;
  total_reach: number;
  avg_reach: number;
  total_impressions: number;
  avg_impressions: number;
  total_likes: number;
  total_comments: number;
  total_shares: number;
  total_saves: number;
  total_video_views: number;
  top_post_type: string;
}

export interface PostTypeStat {
  post_type: string;
  post_count: number;
  avg_engagement_rate: number;
  median_engagement_rate: number;
  total_interactions: number;
  avg_reach: number;
}

export interface SentimentStat {
  sentiment: string;
  post_count: number;
  percentage: number;
  avg_engagement_rate: number;
  median_engagement_rate: number;
}

export interface TimeSeriesPoint {
  date: string;
  avg_engagement_rate: number;
  median_engagement_rate: number;
  total_interactions: number;
  reach: number;
  post_count: number;
}

export interface InteractionBreakdown {
  platform: string;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
}

export interface DistributionData {
  er_buckets: { range: string; count: number }[];
  ctr_buckets: { range: string; count: number }[];
}

export interface DashboardSummaryResponse {
  kpis: KPISummary;
  time_series: TimeSeriesPoint[];
  platforms: PlatformStat[];
  post_types: PostTypeStat[];
  sentiments: SentimentStat[];
  interactions_breakdown: InteractionBreakdown[];
  distributions: DistributionData;
  top_posts: PostRecord[];
}

export interface PostsResponse {
  items: PostRecord[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface PostDetailBenchmark {
  post: PostRecord;
  platform_median_er: number;
  platform_avg_er: number;
  overall_median_er: number;
  overall_avg_er: number;
  platform_median_reach: number;
  overall_median_reach: number;
  performance_tier: string;
  performance_notes: string[];
}

export interface PredictionInput {
  platform: string;
  post_type: string;
  sentiment: string;
  followers: number;
  impressions: number;
  reach: number;
  video_views: number;
  hashtag_count: number;
}

export interface PredictionResponse {
  predicted_engagement_rate_pct: number;
  estimated_engagement_count: number;
  confidence_interval: {
    lower_bound: number;
    upper_bound: number;
  };
  selected_model: string;
  baseline_predicted_er_pct: number;
  model_r2_score: number;
  model_mae: number;
  reliability_warning?: string;
  input_features: Record<string, any>;
  formula_basis: string;
}

export interface ModelMetricItem {
  model_name: string;
  mae: number;
  rmse: number;
  r2: number;
  is_baseline: boolean;
  cv_r2_mean: number;
  cv_r2_std: number;
}

export interface ModelMetricsResponse {
  train_size: number;
  test_size: number;
  target_variable: string;
  feature_names: string[];
  models: ModelMetricItem[];
  best_model_name: string;
  feature_importances: Record<string, number>;
  dataset_limitation_note: string;
}

export interface DataQualityReport {
  total_rows: number;
  total_columns: number;
  duplicate_rows: number;
  missing_values_by_column: Record<string, number>;
  negative_values_found: number;
  outliers_detected: number;
  outlier_percentage: number;
  formula_verified: string;
  reach_zero_count: number;
  impressions_less_than_reach: number;
  high_er_count: number;
  data_types: Record<string, string>;
  dataset_source: string;
  last_updated: string;
}

export interface InsightItem {
  id: string;
  category: string;
  title: string;
  finding: string;
  sample_size: number;
  confidence: string;
  recommendation: string;
}

export interface DatasetInfo {
  active_dataset_name: string;
  is_custom_dataset: boolean;
  total_records: number;
  columns: string[];
  date_range: {
    min: string;
    max: string;
  };
  platforms: string[];
  post_types: string[];
  sentiments: string[];
  last_updated: string;
}
