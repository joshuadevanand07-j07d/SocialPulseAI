import React, { useEffect, useState } from 'react';
import {
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  TrendingUp,
  Globe,
  Layers,
  Hash,
  Smile,
  ShieldAlert,
} from 'lucide-react';
import { FilterState, InsightItem } from '../types';
import { api } from '../services/api';

interface InsightsPageProps {
  filters: FilterState;
}

export const InsightsPage: React.FC<InsightsPageProps> = ({ filters }) => {
  const [insights, setInsights] = useState<InsightItem[]>([]);
  const [sampleSize, setSampleSize] = useState<number>(0);
  const [disclaimer, setDisclaimer] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    api.getInsights(filters)
      .then((res) => {
        if (mounted) {
          setInsights(res.insights);
          setSampleSize(res.sample_size);
          setDisclaimer(res.disclaimer);
        }
      })
      .catch((err) => console.error(err))
      .finally(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [filters]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'platform':
        return <Globe className="w-5 h-5 text-blue-400" />;
      case 'content_type':
        return <Layers className="w-5 h-5 text-pink-400" />;
      case 'hashtag':
        return <Hash className="w-5 h-5 text-violet-400" />;
      case 'sentiment':
        return <Smile className="w-5 h-5 text-emerald-400" />;
      case 'anomaly':
      default:
        return <ShieldAlert className="w-5 h-5 text-amber-400" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center space-y-3 text-slate-400">
          <div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-medium">Extracting data-grounded observations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-[#111827] p-5 rounded-xl border border-[#1e293b] shadow-md space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
              <Lightbulb className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Data-Grounded Insights & Recommendations</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Statistically conservative observations derived directly from {sampleSize} active filtered posts.
              </p>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded bg-[#162035] text-slate-300 border border-[#263554]">
            Sample: <strong>{sampleSize}</strong> records
          </span>
        </div>

        <p className="text-[11px] text-slate-400 pt-2 border-t border-[#1e293b] italic">
          {disclaimer}
        </p>
      </div>

      {/* Insights Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {insights.map((item) => (
          <div
            key={item.id}
            className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md flex flex-col justify-between space-y-4 hover:border-slate-700 transition-colors"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 rounded-lg bg-[#162035] border border-[#263554]">
                    {getCategoryIcon(item.category)}
                  </div>
                  <h3 className="text-sm font-bold text-white leading-snug">{item.title}</h3>
                </div>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                    item.confidence === 'High'
                      ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/40'
                      : item.confidence === 'Moderate'
                      ? 'bg-blue-950/70 text-blue-300 border border-blue-500/40'
                      : 'bg-amber-950/70 text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {item.confidence}
                </span>
              </div>

              {/* Data Finding */}
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554] text-xs text-slate-300 leading-relaxed mb-3">
                <span className="font-semibold text-slate-400 block mb-0.5 text-[11px] uppercase tracking-wide">
                  Observed Pattern (n={item.sample_size}):
                </span>
                {item.finding}
              </div>

              {/* Actionable recommendation */}
              <div className="text-xs text-slate-300 space-y-1">
                <span className="font-semibold text-violet-400 text-[11px] uppercase tracking-wide flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Strategic Recommendation</span>
                </span>
                <p className="text-slate-300 leading-relaxed pl-1">
                  {item.recommendation}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
