import React from 'react';
import {
  FileText,
  Heart,
  Eye,
  Percent,
  PlaySquare,
  Globe,
  Share2,
  Bookmark,
  MessageCircle,
  TrendingUp,
  AlertTriangle,
  ArrowUpRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { DashboardSummaryResponse, PostRecord } from '../types';
import { MetricCard } from '../components/MetricCard';
import { PlatformBadge, SentimentBadge, OutlierBadge } from '../components/Badges';

interface DashboardPageProps {
  summary: DashboardSummaryResponse | null;
  loading: boolean;
  onSelectPost: (postId: string) => void;
}

const COLORS = ['#8B5CF6', '#06B6D4', '#3B82F6', '#EC4899', '#10B981', '#F59E0B'];

export const DashboardPage: React.FC<DashboardPageProps> = ({
  summary,
  loading,
  onSelectPost,
}) => {
  if (loading || !summary) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center space-y-3 text-slate-400">
          <div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-medium">Computing analytics from active dataset...</p>
        </div>
      </div>
    );
  }

  const { kpis, time_series, platforms, post_types, sentiments, interactions_breakdown, distributions, top_posts } = summary;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* KPI Section */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <MetricCard
          title="Total Posts"
          value={kpis.total_posts.toLocaleString()}
          subtitle={`${kpis.platform_count} Platforms Active`}
          icon={<FileText className="w-4 h-4 text-violet-400" />}
          tooltip="Total number of social media posts matching the active filter criteria."
          accentColor="border-violet-900/40"
        />
        <MetricCard
          title="Total Interactions"
          value={kpis.total_interactions.toLocaleString()}
          subtitle={`${kpis.total_likes.toLocaleString()} likes • ${kpis.total_comments.toLocaleString()} comments`}
          icon={<Heart className="w-4 h-4 text-rose-400" />}
          tooltip="Sum of Likes + Comments + Shares + Saves across all filtered posts."
          accentColor="border-rose-900/40"
        />
        <MetricCard
          title="Total Reach & Impressions"
          value={kpis.total_reach.toLocaleString()}
          subtitle={`${kpis.total_impressions.toLocaleString()} Impressions`}
          icon={<Eye className="w-4 h-4 text-cyan-400" />}
          tooltip="Reach represents unique audience exposed; Impressions represents total content views."
          accentColor="border-cyan-900/40"
        />
        <MetricCard
          title="Avg Engagement Rate"
          value={`${kpis.avg_engagement_rate}%`}
          subtitle={`Median: ${kpis.median_engagement_rate}%`}
          icon={<Percent className="w-4 h-4 text-emerald-400" />}
          tooltip="Calculated as (Total Interactions / Reach) * 100. Median is robust against extreme viral outliers."
          accentColor="border-emerald-900/40"
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <MetricCard
          title="Avg Click-Through (CTR)"
          value={`${kpis.avg_ctr}%`}
          subtitle={`Median: ${kpis.median_ctr}%`}
          icon={<TrendingUp className="w-4 h-4 text-amber-400" />}
          tooltip="Average click-through percentage of exposed viewers."
          accentColor="border-amber-900/40"
        />
        <MetricCard
          title="Total Video Views"
          value={kpis.total_video_views.toLocaleString()}
          subtitle="Across Video, Reel & Live posts"
          icon={<PlaySquare className="w-4 h-4 text-sky-400" />}
          tooltip="Accumulated video playback count across video-based post types."
          accentColor="border-sky-900/40"
        />
        <MetricCard
          title="Shares & Saves"
          value={(kpis.total_shares + kpis.total_saves).toLocaleString()}
          subtitle={`${kpis.total_shares.toLocaleString()} shares • ${kpis.total_saves.toLocaleString()} saves`}
          icon={<Share2 className="w-4 h-4 text-indigo-400" />}
          tooltip="High-intent advocacy and retention interactions."
          accentColor="border-indigo-900/40"
        />
        <MetricCard
          title="Flagged Outliers"
          value={kpis.outlier_count}
          subtitle={kpis.outlier_count > 0 ? "ER > 100% or Reach Inversion" : "Clean Distribution"}
          icon={<AlertTriangle className="w-4 h-4 text-amber-400" />}
          tooltip="Records where interactions exceed unique Reach or exhibit extreme statistical deviation."
          accentColor={kpis.outlier_count > 0 ? "border-amber-900/60" : "border-slate-800"}
        />
      </div>

      {/* Row 1: Engagement Over Time & Platform Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timeline Chart */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Engagement Over Time</h3>
              <p className="text-xs text-slate-400">Average Engagement Rate % and Total Interactions by publication date</p>
            </div>
            <span className="text-[11px] text-slate-400 bg-[#162035] px-2.5 py-1 rounded-md border border-[#263554]">
              {time_series.length} data points
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={time_series} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="erGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, 'Avg Engagement Rate']}
                />
                <Area type="monotone" dataKey="avg_engagement_rate" stroke="#8B5CF6" strokeWidth={2} fillOpacity={1} fill="url(#erGradient)" name="Avg ER %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sentiment Distribution */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md flex flex-col">
          <h3 className="text-sm font-semibold text-white">Audience Sentiment Mix</h3>
          <p className="text-xs text-slate-400 mb-4">Post categorization and observed share</p>

          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sentiments}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="post_count"
                  nameKey="sentiment"
                >
                  {sentiments.map((entry, index) => {
                    const color = entry.sentiment.toLowerCase() === 'positive' ? '#10B981' : entry.sentiment.toLowerCase() === 'negative' ? '#F43F5E' : '#F59E0B';
                    return <Cell key={`cell-${index}`} fill={color} />;
                  })}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} posts`, 'Count']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-[#1e293b] text-center">
            {sentiments.map((s) => (
              <div key={s.sentiment} className="text-xs">
                <span className="text-slate-400 block text-[11px]">{s.sentiment}</span>
                <span className="font-semibold text-white">{s.percentage}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Row 2: Platform Comparison & Content Type Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Engagement Rate by Platform */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Engagement Rate by Platform</h3>
              <p className="text-xs text-slate-400">Mean vs Median Engagement Rate % (highlighting skew)</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={platforms} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="platform" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="median_engagement_rate" fill="#8B5CF6" name="Median ER %" radius={[4, 4, 0, 0]} />
                <Bar dataKey="avg_engagement_rate" fill="#06B6D4" name="Mean ER %" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Engagement by Post Type */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Performance by Content Format</h3>
              <p className="text-xs text-slate-400">Median Engagement Rate % by Post Type</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={post_types} layout="vertical" margin={{ top: 10, right: 20, left: 20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                <XAxis type="number" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis dataKey="post_type" type="category" stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, 'Median ER %']}
                />
                <Bar dataKey="median_engagement_rate" fill="#3B82F6" name="Median ER %" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 3: Interactions Composition & Distribution Histograms */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Interactions Stacked Bar */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
          <h3 className="text-sm font-semibold text-white">Interaction Breakdown by Platform</h3>
          <p className="text-xs text-slate-400 mb-4">Proportion of Likes, Comments, Shares, and Saves</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={interactions_breakdown} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="platform" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="likes" stackId="a" fill="#3B82F6" name="Likes" />
                <Bar dataKey="comments" stackId="a" fill="#10B981" name="Comments" />
                <Bar dataKey="shares" stackId="a" fill="#F59E0B" name="Shares" />
                <Bar dataKey="saves" stackId="a" fill="#8B5CF6" name="Saves" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* ER Distribution Histogram */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
          <h3 className="text-sm font-semibold text-white">Engagement Rate Distribution</h3>
          <p className="text-xs text-slate-400 mb-4">Frequency count of posts across engagement rate ranges</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={distributions.er_buckets} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="range" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} posts`, 'Post Count']}
                />
                <Bar dataKey="count" fill="#EC4899" name="Posts Count" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 4: Top Performing Posts Table */}
      <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Top-Performing Posts in Selected View</h3>
            <p className="text-xs text-slate-400">Ranked by calculated Engagement Rate %</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#162035] text-slate-400 border-b border-[#263554] uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Post ID</th>
                <th className="py-2.5 px-3">Platform</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3 text-right">Reach</th>
                <th className="py-2.5 px-3 text-right">Interactions</th>
                <th className="py-2.5 px-3 text-right">Engagement Rate</th>
                <th className="py-2.5 px-3 text-right">CTR</th>
                <th className="py-2.5 px-3">Sentiment</th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {top_posts.map((post) => (
                <tr key={post.Post_ID} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-semibold text-white">{post.Post_ID}</td>
                  <td className="py-2.5 px-3"><PlatformBadge platform={post.Platform} /></td>
                  <td className="py-2.5 px-3 text-slate-300">{post.Post_Type}</td>
                  <td className="py-2.5 px-3 text-slate-400">{post.Date}</td>
                  <td className="py-2.5 px-3 text-right">{post.Reach.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right font-medium text-slate-200">{post.Total_Interactions.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right">
                    <span className="font-bold text-violet-400">{post["Engagement_Rate_%"].toFixed(2)}%</span>
                    {post.Is_Outlier && <OutlierBadge isOutlier={true} reason={post.Outlier_Reason} />}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400">{post["CTR_%"].toFixed(2)}%</td>
                  <td className="py-2.5 px-3"><SentimentBadge sentiment={post.Sentiment} /></td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => onSelectPost(post.Post_ID)}
                      className="inline-flex items-center space-x-1 text-violet-400 hover:text-violet-300 font-medium hover:underline"
                    >
                      <span>Analyze</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
