import React, { useState } from 'react';
import {
  FileDown,
  FileSpreadsheet,
  FileText,
  Printer,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Filter,
} from 'lucide-react';
import { FilterState, DashboardSummaryResponse } from '../types';
import { api } from '../services/api';

interface DownloadsPageProps {
  filters: FilterState;
  summary: DashboardSummaryResponse | null;
}

export const DownloadsPage: React.FC<DownloadsPageProps> = ({
  filters,
  summary,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const notifyDownload = (label: string) => {
    setDownloadSuccess(`Initiated download: ${label}`);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-[#111827] p-5 rounded-xl border border-[#1e293b] shadow-md flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
            <FileDown className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <span>Downloads, Exports & Executive Reports</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Generate real Excel, CSV, and professionally formatted PDF summary exports.
            </p>
          </div>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#162035] text-slate-200 hover:text-white border border-[#263554] transition-colors"
          title="Print page to PDF using browser printer"
        >
          <Printer className="w-4 h-4 text-violet-400" />
          <span>Printable Layout</span>
        </button>
      </div>

      {downloadSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center space-x-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Export Options Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. PDF Executive Report */}
        <div className="p-5 rounded-xl bg-[#111827] border border-violet-500/40 shadow-md flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2.5 mb-2">
              <div className="p-2 rounded-lg bg-violet-600/20 border border-violet-500/30 text-violet-400">
                <FileText className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Executive PDF Report</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Professionally styled multi-page PDF summary compiled via ReportLab. Includes active filter metrics, KPI cards, cross-platform benchmarks, key insights, and ML model evaluation metrics.
            </p>
          </div>

          <a
            href={api.getExportPdfUrl(filters)}
            download
            onClick={() => notifyDownload('Executive PDF Report')}
            className="w-full py-2.5 px-4 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-semibold text-xs text-center flex items-center justify-center space-x-2 shadow-md shadow-violet-600/20 transition-all"
          >
            <FileDown className="w-4 h-4" />
            <span>Download Executive PDF</span>
          </a>
        </div>

        {/* 2. Filtered Dataset CSV */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2.5 mb-2">
              <div className="p-2 rounded-lg bg-cyan-600/20 border border-cyan-500/30 text-cyan-400">
                <Filter className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Filtered Records (CSV)</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Downloads the current filtered subset ({summary?.kpis.total_posts || 0} records) as a structured CSV file, honoring all active platform, post type, date, search, and outlier settings.
            </p>
          </div>

          <a
            href={api.getExportCsvUrl(filters)}
            download
            onClick={() => notifyDownload('Filtered Records CSV')}
            className="w-full py-2.5 px-4 rounded-lg bg-[#162035] hover:bg-slate-800 text-slate-200 border border-[#263554] font-semibold text-xs text-center flex items-center justify-center space-x-2 transition-colors"
          >
            <FileDown className="w-4 h-4 text-cyan-400" />
            <span>Download Filtered CSV</span>
          </a>
        </div>

        {/* 3. Original Dataset (Excel .xlsx) */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2.5 mb-2">
              <div className="p-2 rounded-lg bg-emerald-600/20 border border-emerald-500/30 text-emerald-400">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Original Supplied Dataset (Excel)</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              The genuine, unaltered 300-record Excel workbook (<code>Social_Media_Engagement_Analysis_Dataset_300.xlsx</code>) preserved in its native binary format.
            </p>
          </div>

          <a
            href={api.getExportOriginalUrl()}
            download
            onClick={() => notifyDownload('Original Dataset (.xlsx)')}
            className="w-full py-2.5 px-4 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/40 text-emerald-300 border border-emerald-500/40 font-semibold text-xs text-center flex items-center justify-center space-x-2 transition-colors"
          >
            <FileDown className="w-4 h-4" />
            <span>Download Original Excel</span>
          </a>
        </div>

        {/* 4. Cleaned & Validated Dataset (CSV) */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2.5 mb-2">
              <div className="p-2 rounded-lg bg-blue-600/20 border border-blue-500/30 text-blue-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Cleaned / Validated Dataset (CSV)</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Validated dataset with data types parsed, total interactions computed, and extreme anomalies (ER &gt; 100%) filtered out for robust quantitative analysis.
            </p>
          </div>

          <a
            href={api.getExportCleanedUrl()}
            download
            onClick={() => notifyDownload('Cleaned Dataset CSV')}
            className="w-full py-2.5 px-4 rounded-lg bg-[#162035] hover:bg-slate-800 text-slate-200 border border-[#263554] font-semibold text-xs text-center flex items-center justify-center space-x-2 transition-colors"
          >
            <FileDown className="w-4 h-4 text-blue-400" />
            <span>Download Cleaned CSV</span>
          </a>
        </div>
      </div>

      {/* Printable Report Preview */}
      <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-4 print:bg-white print:text-black">
        <div className="flex items-center justify-between pb-3 border-b border-[#1e293b]">
          <h3 className="text-sm font-bold text-white print:text-black">Executive Summary Sheet Preview</h3>
          <span className="text-xs text-slate-400">Printable Layout</span>
        </div>

        <div className="space-y-4 text-xs text-slate-300">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 bg-[#162035] rounded-lg">
              <span className="text-slate-400 block text-[11px]">Active Posts</span>
              <strong className="text-white text-base">{summary?.kpis.total_posts.toLocaleString()}</strong>
            </div>
            <div className="p-3 bg-[#162035] rounded-lg">
              <span className="text-slate-400 block text-[11px]">Total Reach</span>
              <strong className="text-white text-base">{summary?.kpis.total_reach.toLocaleString()}</strong>
            </div>
            <div className="p-3 bg-[#162035] rounded-lg">
              <span className="text-slate-400 block text-[11px]">Median ER%</span>
              <strong className="text-violet-400 text-base">{summary?.kpis.median_engagement_rate}%</strong>
            </div>
            <div className="p-3 bg-[#162035] rounded-lg">
              <span className="text-slate-400 block text-[11px]">Avg CTR%</span>
              <strong className="text-cyan-400 text-base">{summary?.kpis.avg_ctr}%</strong>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 italic">
            All reports and CSV files are computed dynamically from the currently active dataset in memory.
          </p>
        </div>
      </div>
    </div>
  );
};
