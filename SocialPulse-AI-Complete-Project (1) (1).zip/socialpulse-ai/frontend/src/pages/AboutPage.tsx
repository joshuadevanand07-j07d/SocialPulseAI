import React from 'react';
import {
  BookOpen,
  Database,
  Code2,
  BrainCircuit,
  ShieldAlert,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto text-slate-200">
      {/* Page Title */}
      <div className="bg-[#111827] p-5 rounded-xl border border-[#1e293b] shadow-md flex items-center space-x-3">
        <div className="w-10 h-10 rounded-xl bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
          <BookOpen className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-base font-bold text-white">About & Methodology Documentation</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Architectural standards, mathematical formulas, data integrity protocols, and machine learning specifications.
          </p>
        </div>
      </div>

      {/* 1. Dataset Provenance */}
      <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center space-x-2">
          <Database className="w-4 h-4 text-violet-400" />
          <span>1. Dataset Provenance & Scope</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          This application operates on the supplied benchmark dataset containing <strong>300 observed social media records</strong> across four major networks: <strong>Facebook, Instagram, LinkedIn, and X (formerly Twitter)</strong>.
          The primary source file is preserved intact on disk at <code>Social_Media_Engagement_Analysis_Dataset_300.xlsx</code> (sheet: <code>Social_Media_Engagement</code>).
        </p>

        <div className="p-3.5 rounded-lg bg-amber-950/30 border border-amber-500/30 text-amber-300 text-xs flex items-start space-x-2.5">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong>Historical Data Notice:</strong> This dataset represents a static, historical observation sample.
            It does not automatically sync live feeds or stream real-time data from social networks. Any future social platform integration must use official, permitted partner APIs and credentials stored securely in environment variables.
          </div>
        </div>
      </div>

      {/* 2. Metric Formulas */}
      <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center space-x-2">
          <Code2 className="w-4 h-4 text-cyan-400" />
          <span>2. Standard Metric Definitions & Exact Formulas</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-[#162035] border border-[#263554] space-y-1">
            <span className="font-semibold text-white block">Total Interactions</span>
            <code className="text-violet-300 font-mono text-[11px] block">
              Likes + Comments + Shares + Saves
            </code>
            <p className="text-slate-400 text-[11px]">
              Aggregates all direct audience reaction touchpoints on a given post.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-[#162035] border border-[#263554] space-y-1">
            <span className="font-semibold text-white block">Engagement Rate %</span>
            <code className="text-violet-300 font-mono text-[11px] block">
              (Total Interactions / Reach) × 100
            </code>
            <p className="text-slate-400 text-[11px]">
              Strictly verified against the supplied dataset column (r &gt; 0.99999). Measures engagement intensity per unique account exposed.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-[#162035] border border-[#263554] space-y-1">
            <span className="font-semibold text-white block">Click-Through Rate (CTR %)</span>
            <code className="text-cyan-300 font-mono text-[11px] block">
              CTR_% (provided observed rate)
            </code>
            <p className="text-slate-400 text-[11px]">
              Reflects percentage of viewer actions resulting in direct outbound link clicks or CTA triggers.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-[#162035] border border-[#263554] space-y-1">
            <span className="font-semibold text-white block">Estimated Engagements (Inference)</span>
            <code className="text-cyan-300 font-mono text-[11px] block">
              (Predicted_ER% × Expected_Reach) / 100
            </code>
            <p className="text-slate-400 text-[11px]">
              Translates percentage rate estimates into actionable volume approximations for campaign planning.
            </p>
          </div>
        </div>
      </div>

      {/* 3. ML Pipeline & Target Leakage Prevention */}
      <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center space-x-2">
          <BrainCircuit className="w-4 h-4 text-violet-400" />
          <span>3. Machine Learning Methodology & Zero Target Leakage</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          The machine learning pipeline predicts post engagement rate prior to publication:
        </p>

        <ul className="list-disc pl-5 text-xs text-slate-300 space-y-1.5 leading-relaxed">
          <li>
            <strong>Target Variable:</strong> <code>Engagement_Rate_%</code>
          </li>
          <li>
            <strong>Pre-Publication Feature Set:</strong> <code>Platform</code>, <code>Post_Type</code>, <code>Sentiment</code>, <code>Followers</code>, <code>Impressions</code>, <code>Reach</code>, <code>Video_Views</code>, <code>Hashtag_Count</code>.
          </li>
          <li>
            <strong>Strict Absence of Target Leakage:</strong> Post-publication outcomes (actual likes, comments, shares, saves, or CTR) are strictly excluded from input features.
          </li>
          <li>
            <strong>Preprocessing:</strong> Numeric variables normalized with <code>StandardScaler</code>; categorical variables encoded with <code>OneHotEncoder(handle_unknown='ignore')</code> via Scikit-Learn <code>ColumnTransformer</code>.
          </li>
          <li>
            <strong>Model Selection & Cross-Validation:</strong> Evaluated on an 80/20 train/test split with 5-fold cross validation. Compared against a <code>DummyRegressor(strategy='mean')</code> baseline, <code>Ridge</code>, <code>HistGradientBoostingRegressor</code>, and <code>RandomForestRegressor</code>.
          </li>
        </ul>
      </div>

      {/* 4. Data Quality & Outlier Policy */}
      <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>4. Data Quality & Cleaning Policy</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          A fundamental principle of SocialPulse AI is transparent data handling:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 rounded-lg bg-[#162035] border border-[#263554] space-y-1">
            <span className="font-semibold text-slate-200 block">Raw Data Preservation</span>
            <p className="text-slate-400 leading-relaxed">
              No rows or values are silently deleted, capped, or fabricated. Every record is viewable as originally supplied in the Data Explorer.
            </p>
          </div>
          <div className="p-3.5 rounded-lg bg-[#162035] border border-[#263554] space-y-1">
            <span className="font-semibold text-amber-300 block">Configurable Robust Policy</span>
            <p className="text-slate-400 leading-relaxed">
              Posts where interactions exceed recorded unique reach (ER &gt; 100%) are explicitly flagged with reasons and can be filtered via the "Robust View" toggle.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
