import React, { useState, useEffect } from 'react';
import {
  Download,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  FileSpreadsheet,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { PostRecord, FilterState } from '../types';
import { api } from '../services/api';
import { PlatformBadge, SentimentBadge, OutlierBadge } from '../components/Badges';

interface DataExplorerPageProps {
  filters: FilterState;
  onSelectPost: (postId: string) => void;
  onOpenUpload: () => void;
}

export const DataExplorerPage: React.FC<DataExplorerPageProps> = ({
  filters,
  onSelectPost,
  onOpenUpload,
}) => {
  const [posts, setPosts] = useState<PostRecord[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(15);
  const [sortBy, setSortBy] = useState<string>('Date');
  const [sortDesc, setSortDesc] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const data = await api.getPosts(page, pageSize, sortBy, sortDesc, filters);
      setPosts(data.items);
      setTotal(data.total);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, [page, pageSize, sortBy, sortDesc, filters]);

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortDesc(!sortDesc);
    } else {
      setSortBy(column);
      setSortDesc(true);
    }
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Header and Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111827] p-4 rounded-xl border border-[#1e293b] shadow-md">
        <div>
          <h2 className="text-base font-bold text-white flex items-center space-x-2">
            <span>Historical Dataset Explorer</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-violet-950/80 text-violet-300 border border-violet-500/30">
              {total} Posts Match Filters
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Explore, sort, filter, and audit individual observed social media records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Download Filtered CSV */}
          <a
            href={api.getExportCsvUrl(filters)}
            download
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#162035] text-slate-200 hover:text-white hover:bg-slate-800 border border-[#263554] transition-colors"
            title="Export currently filtered rows to CSV"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export Filtered CSV</span>
          </a>

          {/* Download Original Dataset */}
          <a
            href={api.getExportOriginalUrl()}
            download
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/40 border border-emerald-500/40 transition-colors"
            title="Download original untouched Excel dataset"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Original Excel (.xlsx)</span>
          </a>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="rounded-xl bg-[#111827] border border-[#1e293b] shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#162035] text-slate-400 border-b border-[#263554] uppercase text-[10px] tracking-wider select-none">
              <tr>
                {[
                  { key: 'Post_ID', label: 'Post ID', sortable: true },
                  { key: 'Platform', label: 'Platform', sortable: true },
                  { key: 'Post_Type', label: 'Post Type', sortable: true },
                  { key: 'Date', label: 'Date', sortable: true },
                  { key: 'Followers', label: 'Followers', sortable: true, align: 'text-right' },
                  { key: 'Impressions', label: 'Impressions', sortable: true, align: 'text-right' },
                  { key: 'Reach', label: 'Reach', sortable: true, align: 'text-right' },
                  { key: 'Likes', label: 'Likes', sortable: true, align: 'text-right' },
                  { key: 'Comments', label: 'Comments', sortable: true, align: 'text-right' },
                  { key: 'Shares', label: 'Shares', sortable: true, align: 'text-right' },
                  { key: 'Saves', label: 'Saves', sortable: true, align: 'text-right' },
                  { key: 'Video_Views', label: 'Video Views', sortable: true, align: 'text-right' },
                  { key: 'CTR_%', label: 'CTR %', sortable: true, align: 'text-right' },
                  { key: 'Engagement_Rate_%', label: 'Eng Rate %', sortable: true, align: 'text-right' },
                  { key: 'Sentiment', label: 'Sentiment', sortable: true },
                  { key: 'Hashtag_Count', label: 'Tags', sortable: true, align: 'text-center' },
                  { key: 'action', label: 'Details', sortable: false, align: 'text-center' },
                ].map((col) => (
                  <th
                    key={col.key}
                    onClick={() => col.sortable && handleSort(col.key)}
                    className={`py-3 px-3 ${col.align || 'text-left'} ${
                      col.sortable ? 'cursor-pointer hover:text-white' : ''
                    }`}
                  >
                    <div className={`inline-flex items-center space-x-1 ${col.align === 'text-right' ? 'justify-end' : ''}`}>
                      <span>{col.label}</span>
                      {col.sortable && (
                        <span>
                          {sortBy === col.key ? (
                            sortDesc ? (
                              <ArrowDown className="w-3 h-3 text-violet-400" />
                            ) : (
                              <ArrowUp className="w-3 h-3 text-violet-400" />
                            )
                          ) : (
                            <ArrowUpDown className="w-2.5 h-2.5 text-slate-500 opacity-60" />
                          )}
                        </span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>

            <tbody className="divide-y divide-[#1e293b]">
              {loading ? (
                <tr>
                  <td colSpan={17} className="py-12 text-center text-slate-400">
                    <div className="inline-block w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin mr-2" />
                    Loading records...
                  </td>
                </tr>
              ) : posts.length === 0 ? (
                <tr>
                  <td colSpan={17} className="py-12 text-center text-slate-400">
                    <p className="text-sm font-medium">No records match the current filter selection.</p>
                    <p className="text-xs text-slate-500 mt-1">Try relaxing filters or search terms.</p>
                  </td>
                </tr>
              ) : (
                posts.map((post) => (
                  <tr
                    key={post.Post_ID}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    <td className="py-2.5 px-3 font-semibold text-white">
                      {post.Post_ID}
                    </td>
                    <td className="py-2.5 px-3">
                      <PlatformBadge platform={post.Platform} />
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{post.Post_Type}</td>
                    <td className="py-2.5 px-3 text-slate-400">{post.Date}</td>
                    <td className="py-2.5 px-3 text-right">{post.Followers.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right">{post.Impressions.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right font-medium">{post.Reach.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right">{post.Likes.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right">{post.Comments.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right">{post.Shares.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right">{post.Saves.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right">{post.Video_Views.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right font-medium">{post["CTR_%"].toFixed(2)}%</td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="flex items-center justify-end space-x-1">
                        <span className="font-bold text-violet-300">
                          {post["Engagement_Rate_%"].toFixed(2)}%
                        </span>
                        <OutlierBadge isOutlier={post.Is_Outlier} reason={post.Outlier_Reason} />
                      </div>
                    </td>
                    <td className="py-2.5 px-3">
                      <SentimentBadge sentiment={post.Sentiment} />
                    </td>
                    <td className="py-2.5 px-3 text-center">{post.Hashtag_Count}</td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={() => onSelectPost(post.Post_ID)}
                        className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-violet-300 transition-colors"
                        title="View post deep-dive analytics"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Toolbar */}
        <div className="p-3 bg-[#162035] border-t border-[#1e293b] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center space-x-2">
            <span>Show rows:</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
              className="px-2 py-1 rounded bg-[#111827] border border-[#263554] text-slate-200"
            >
              <option value={10}>10</option>
              <option value={15}>15</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span>
              Showing {(page - 1) * pageSize + 1} - {Math.min(page * pageSize, total)} of {total}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setPage(page - 1)}
              disabled={page <= 1}
              className="p-1.5 rounded-lg border border-[#263554] bg-[#111827] text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              title="Previous Page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-medium">
              Page {page} of {totalPages}
            </span>
            <button
              onClick={() => setPage(page + 1)}
              disabled={page >= totalPages}
              className="p-1.5 rounded-lg border border-[#263554] bg-[#111827] text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              title="Next Page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
