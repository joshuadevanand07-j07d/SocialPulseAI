import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Search,
  Calendar,
  Eye,
  Heart,
  Share2,
  Bookmark,
  MessageCircle,
  Hash,
  Smile,
  BarChart2,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import { PostDetailBenchmark } from '../types';
import { api } from '../services/api';
import { PlatformBadge, SentimentBadge, OutlierBadge } from '../components/Badges';

interface PostPerformancePageProps {
  selectedPostId: string;
  onSelectPostId: (id: string) => void;
}

export const PostPerformancePage: React.FC<PostPerformancePageProps> = ({
  selectedPostId,
  onSelectPostId,
}) => {
  const [detail, setDetail] = useState<PostDetailBenchmark | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchId, setSearchId] = useState<string>(selectedPostId || 'P001');
  const [error, setError] = useState<string | null>(null);

  const fetchDetail = async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getPostDetail(id);
      setDetail(data);
      setSearchId(data.post.Post_ID);
    } catch (err: any) {
      setError(err.message || `Post '${id}' not found.`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDetail(selectedPostId || 'P001');
  }, [selectedPostId]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchId.trim()) {
      onSelectPostId(searchId.trim().toUpperCase());
      fetchDetail(searchId.trim().toUpperCase());
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header & Post ID Lookup */}
      <div className="bg-[#111827] p-5 rounded-xl border border-[#1e293b] shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-violet-400" />
            <span>Post Performance Analysis & Benchmarking</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Individual post breakdown evaluated against platform-specific and global medians.
          </p>
        </div>

        {/* Search / Select Post ID */}
        <form onSubmit={handleSearchSubmit} className="flex items-center space-x-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="e.g. P001, P045..."
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#162035] border border-[#263554] text-white focus:outline-none focus:border-violet-500 uppercase font-medium w-36"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-violet-600 hover:bg-violet-500 text-white transition-colors"
          >
            Inspect
          </button>
        </form>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center min-h-[300px]">
          <div className="flex flex-col items-center space-y-2 text-slate-400">
            <div className="w-7 h-7 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-xs">Loading post performance profile...</span>
          </div>
        </div>
      ) : detail ? (
        <div className="space-y-6">
          {/* Main Post Overview Card */}
          <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#1e293b]">
              <div className="flex items-center space-x-3">
                <span className="text-xl font-extrabold text-white">{detail.post.Post_ID}</span>
                <PlatformBadge platform={detail.post.Platform} />
                <span className="text-xs px-2.5 py-0.5 rounded-md bg-[#162035] text-slate-300 border border-[#263554]">
                  {detail.post.Post_Type}
                </span>
                <SentimentBadge sentiment={detail.post.Sentiment} />
                <OutlierBadge isOutlier={detail.post.Is_Outlier} reason={detail.post.Outlier_Reason} />
              </div>

              {/* Performance Tier Badge */}
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-400 font-medium">Evaluation Tier:</span>
                <span className="px-3 py-1 text-xs font-bold rounded-lg bg-violet-950/80 text-violet-300 border border-violet-500/40">
                  {detail.performance_tier}
                </span>
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554]">
                <span className="text-[11px] text-slate-400 block">Publication Date</span>
                <span className="text-sm font-semibold text-white mt-1 block">{detail.post.Date}</span>
              </div>
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554]">
                <span className="text-[11px] text-slate-400 block">Follower Base</span>
                <span className="text-sm font-semibold text-white mt-1 block">{detail.post.Followers.toLocaleString()}</span>
              </div>
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554]">
                <span className="text-[11px] text-slate-400 block">Unique Reach</span>
                <span className="text-sm font-semibold text-cyan-400 mt-1 block">{detail.post.Reach.toLocaleString()}</span>
              </div>
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554]">
                <span className="text-[11px] text-slate-400 block">Impressions</span>
                <span className="text-sm font-semibold text-white mt-1 block">{detail.post.Impressions.toLocaleString()}</span>
              </div>
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554]">
                <span className="text-[11px] text-slate-400 block">Engagement Rate</span>
                <span className="text-sm font-bold text-violet-400 mt-1 block">{detail.post["Engagement_Rate_%"].toFixed(2)}%</span>
              </div>
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554]">
                <span className="text-[11px] text-slate-400 block">Click-Through (CTR)</span>
                <span className="text-sm font-semibold text-emerald-400 mt-1 block">{detail.post["CTR_%"].toFixed(2)}%</span>
              </div>
            </div>

            {/* Interaction Breakdown */}
            <div className="p-4 rounded-lg bg-[#0e1424] border border-[#1e293b]">
              <span className="text-xs font-semibold text-slate-300 block mb-3">
                Total Interactions: {detail.post.Total_Interactions.toLocaleString()}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-rose-400 shrink-0" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">Likes</span>
                    <span className="font-semibold text-white">{detail.post.Likes.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <MessageCircle className="w-4 h-4 text-blue-400 shrink-0" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">Comments</span>
                    <span className="font-semibold text-white">{detail.post.Comments.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Share2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">Shares</span>
                    <span className="font-semibold text-white">{detail.post.Shares.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Bookmark className="w-4 h-4 text-violet-400 shrink-0" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">Saves</span>
                    <span className="font-semibold text-white">{detail.post.Saves.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Benchmark Comparison Matrix */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-4">
              <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
                <BarChart2 className="w-4 h-4 text-violet-400" />
                <span>Benchmark Against Medians</span>
              </h3>

              <div className="space-y-3 text-xs">
                {/* Post ER vs Platform Median */}
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>This Post ER%: <strong className="text-violet-400">{detail.post["Engagement_Rate_%"].toFixed(2)}%</strong></span>
                    <span className="text-slate-400">{detail.post.Platform} Median: {detail.platform_median_er.toFixed(2)}%</span>
                  </div>
                  <div className="w-full bg-[#162035] h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-violet-500 h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min(100, (detail.post["Engagement_Rate_%"] / Math.max(detail.platform_median_er * 2, 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Post ER vs Overall Median */}
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>This Post ER%: <strong className="text-violet-400">{detail.post["Engagement_Rate_%"].toFixed(2)}%</strong></span>
                    <span className="text-slate-400">All Platforms Median: {detail.overall_median_er.toFixed(2)}%</span>
                  </div>
                  <div className="w-full bg-[#162035] h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-cyan-500 h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min(100, (detail.post["Engagement_Rate_%"] / Math.max(detail.overall_median_er * 2, 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Reach vs Overall Median */}
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>This Post Reach: <strong className="text-white">{detail.post.Reach.toLocaleString()}</strong></span>
                    <span className="text-slate-400">Overall Median Reach: {detail.overall_median_reach.toLocaleString()}</span>
                  </div>
                  <div className="w-full bg-[#162035] h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-blue-500 h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min(100, (detail.post.Reach / Math.max(detail.overall_median_reach * 2, 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Contextual Analytical Observations */}
            <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-3">
              <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Performance Insights & Context</span>
              </h3>

              <div className="space-y-2">
                {detail.performance_notes.map((note, idx) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-[#162035] text-xs text-slate-300 leading-relaxed border border-[#263554]">
                    • {note}
                  </div>
                ))}
              </div>

              <p className="text-[11px] text-slate-500 italic pt-2">
                Note: Evaluated strictly as historical observation. High engagement on individual posts does not prove direct causation between format/hashtags and audience response.
              </p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
