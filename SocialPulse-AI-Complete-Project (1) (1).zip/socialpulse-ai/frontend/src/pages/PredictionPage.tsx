import React, { useState, useEffect } from 'react';
import {
  BrainCircuit,
  Sparkles,
  Info,
  TrendingUp,
  Percent,
  Calculator,
  ShieldAlert,
  Sliders,
  CheckCircle,
  HelpCircle,
  Loader2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { PredictionInput, PredictionResponse, ModelMetricsResponse } from '../types';
import { api } from '../services/api';

interface PredictionPageProps {
  platforms: string[];
  postTypes: string[];
  sentiments: string[];
}

export const PredictionPage: React.FC<PredictionPageProps> = ({
  platforms,
  postTypes,
  sentiments,
}) => {
  const [form, setForm] = useState<PredictionInput>({
    platform: 'Instagram',
    post_type: 'Carousel',
    sentiment: 'Positive',
    followers: 65000,
    impressions: 22000,
    reach: 11000,
    video_views: 0,
    hashtag_count: 5,
  });

  const [prediction, setPrediction] = useState<PredictionResponse | null>(null);
  const [metrics, setMetrics] = useState<ModelMetricsResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [metricsLoading, setMetricsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.getModelMetrics()
      .then((data) => setMetrics(data))
      .catch((err) => console.error('Failed to load metrics:', err))
      .finally(() => setMetricsLoading(false));

    // Initial prediction run
    handlePredict();
  }, []);

  const handlePredict = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await api.predict(form);
      setPrediction(res);
    } catch (err: any) {
      setError(err.message || 'Prediction failed');
    } finally {
      setLoading(false);
    }
  };

  const featureImportanceData = metrics
    ? Object.entries(metrics.feature_importances).map(([name, val]) => ({
        name,
        importance: val,
      }))
    : [];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner & Transparency Guarantee */}
      <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Machine Learning Engagement Rate Predictor</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-violet-950/80 text-violet-300 border border-violet-500/30">
                  Scikit-Learn Pipeline
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Pre-publication parameter simulation. Strictly excludes future interaction outcomes (zero target leakage).
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs px-2.5 py-1 rounded bg-[#162035] text-slate-300 border border-[#263554]">
              Champion Model: <strong>{metrics?.best_model_name || 'Random Forest'}</strong>
            </span>
          </div>
        </div>

        {/* Reliability alert for small dataset */}
        <div className="p-3 rounded-lg bg-amber-950/30 border border-amber-500/30 text-amber-300 text-xs flex items-start space-x-2">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong>Sample Size Disclaimer:</strong> This machine learning model is trained on the 300 historical records from the active workbook.
            Metrics reflect an 80/20 train/test split. Predicted rates are analytical approximations of historical trends, not guaranteed engagement outcomes.
          </div>
        </div>
      </div>

      {/* Main Grid: Form on Left, Output & Models on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Inputs (5 columns) */}
        <div className="lg:col-span-5 p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center space-x-2 mb-4">
              <Sliders className="w-4 h-4 text-violet-400" />
              <span>Proposed Post Parameters</span>
            </h3>

            <form onSubmit={handlePredict} className="space-y-4">
              {/* Platform */}
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Social Media Platform
                </label>
                <select
                  value={form.platform}
                  onChange={(e) => setForm({ ...form, platform: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-[#162035] border border-[#263554] text-white focus:outline-none focus:border-violet-500"
                >
                  {platforms.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              {/* Post Type & Sentiment */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Post Type / Format
                  </label>
                  <select
                    value={form.post_type}
                    onChange={(e) => setForm({ ...form, post_type: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-[#162035] border border-[#263554] text-white focus:outline-none focus:border-violet-500"
                  >
                    {postTypes.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Tone / Sentiment
                  </label>
                  <select
                    value={form.sentiment}
                    onChange={(e) => setForm({ ...form, sentiment: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-[#162035] border border-[#263554] text-white focus:outline-none focus:border-violet-500"
                  >
                    {sentiments.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Followers */}
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Account Followers:</span>
                  <span className="font-semibold text-white">{form.followers.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min={1000}
                  max={500000}
                  step={1000}
                  value={form.followers}
                  onChange={(e) => setForm({ ...form, followers: Number(e.target.value) })}
                  className="w-full accent-violet-500 cursor-pointer"
                />
              </div>

              {/* Expected Reach */}
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Expected Unique Reach:</span>
                  <span className="font-semibold text-cyan-400">{form.reach.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min={500}
                  max={50000}
                  step={500}
                  value={form.reach}
                  onChange={(e) => setForm({ ...form, reach: Number(e.target.value) })}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              {/* Expected Impressions */}
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Expected Total Impressions:</span>
                  <span className="font-semibold text-white">{form.impressions.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min={1000}
                  max={80000}
                  step={500}
                  value={form.impressions}
                  onChange={(e) => setForm({ ...form, impressions: Number(e.target.value) })}
                  className="w-full accent-violet-500 cursor-pointer"
                />
              </div>

              {/* Video Views & Hashtags */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Expected Video Views
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={form.video_views}
                    onChange={(e) => setForm({ ...form, video_views: Math.max(0, Number(e.target.value)) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#162035] border border-[#263554] text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Hashtags Count
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={30}
                    value={form.hashtag_count}
                    onChange={(e) => setForm({ ...form, hashtag_count: Math.max(0, Number(e.target.value)) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#162035] border border-[#263554] text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-2.5 px-4 rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-semibold text-xs tracking-wide shadow-md shadow-violet-600/20 transition-all flex items-center justify-center space-x-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Predicting...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate ML Prediction</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>

        {/* Output & Benchmark Results (7 columns) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Prediction Result Display */}
          {prediction && (
            <div className="p-6 rounded-xl bg-gradient-to-br from-[#131b31] via-[#111827] to-[#141d33] border border-violet-500/40 shadow-xl space-y-5">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-bold tracking-wider text-violet-400">
                  Predicted Performance Estimate
                </span>
                <span className="text-[11px] text-slate-400">
                  Model: <strong className="text-slate-200">{prediction.selected_model}</strong>
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Predicted Rate */}
                <div className="p-4 rounded-xl bg-[#0b0f19]/70 border border-[#263554]">
                  <span className="text-xs text-slate-400 block mb-1">
                    Predicted Engagement Rate
                  </span>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-violet-400 via-indigo-300 to-cyan-300">
                      {prediction.predicted_engagement_rate_pct.toFixed(2)}%
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Estimated Range: <strong>{prediction.confidence_interval.lower_bound.toFixed(2)}%</strong> – <strong>{prediction.confidence_interval.upper_bound.toFixed(2)}%</strong>
                  </span>
                </div>

                {/* Estimated Engagement Count */}
                <div className="p-4 rounded-xl bg-[#0b0f19]/70 border border-[#263554]">
                  <span className="text-xs text-slate-400 block mb-1">
                    Estimated Total Engagements
                  </span>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-3xl font-extrabold text-cyan-300">
                      ~{prediction.estimated_engagement_count.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-400">interactions</span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Formula: (ER% × Reach) / 100 on {form.reach.toLocaleString()} reach
                  </span>
                </div>
              </div>

              {/* Baseline Comparison Badge */}
              <div className="p-3 rounded-lg bg-[#162035] border border-[#263554] flex items-center justify-between text-xs">
                <div className="text-slate-300">
                  <span>Baseline (Dummy Mean Prediction): </span>
                  <strong className="text-slate-400">{prediction.baseline_predicted_er_pct.toFixed(2)}%</strong>
                </div>
                <div className="text-violet-300 font-semibold">
                  Model R² on Held-out Data: {prediction.model_r2_score.toFixed(3)}
                </div>
              </div>
            </div>
          )}

          {/* Model Comparison Table */}
          <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">Models Evaluation on Held-Out Test Set</h3>
                <p className="text-xs text-slate-400">Strictly tested on 20% unseen data (60 records) + 5-fold CV</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#162035] text-slate-400 border-b border-[#263554] uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-2 px-3">Model</th>
                    <th className="py-2 px-3">Type</th>
                    <th className="py-2 px-3 text-right">MAE</th>
                    <th className="py-2 px-3 text-right">RMSE</th>
                    <th className="py-2 px-3 text-right">Test R²</th>
                    <th className="py-2 px-3 text-right">5-Fold CV R²</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e293b]">
                  {metrics?.models.map((m) => {
                    const isSelected = m.model_name === metrics.best_model_name;
                    return (
                      <tr
                        key={m.model_name}
                        className={isSelected ? 'bg-violet-950/20 font-semibold text-violet-200' : 'hover:bg-slate-800/30'}
                      >
                        <td className="py-2 px-3 flex items-center space-x-1.5">
                          {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-violet-400" />}
                          <span>{m.model_name}</span>
                        </td>
                        <td className="py-2 px-3 text-slate-400">
                          {m.is_baseline ? 'Baseline' : 'Regressor'}
                        </td>
                        <td className="py-2 px-3 text-right">{m.mae.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right">{m.rmse.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right font-bold">
                          {m.r2.toFixed(3)}
                        </td>
                        <td className="py-2 px-3 text-right text-slate-400">
                          {m.cv_r2_mean.toFixed(3)} ± {m.cv_r2_std.toFixed(3)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Feature Importance Chart */}
          {featureImportanceData.length > 0 && (
            <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
              <h3 className="text-sm font-semibold text-white">Feature Relative Importance (Random Forest)</h3>
              <p className="text-xs text-slate-400 mb-3">Relative percentage contribution to predicted engagement</p>

              <div className="h-44 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={featureImportanceData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                    <XAxis type="number" stroke="#64748b" fontSize={11} domain={[0, 100]} />
                    <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={11} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                      formatter={(val: any) => [`${val}%`, 'Importance']}
                    />
                    <Bar dataKey="importance" fill="#8B5CF6" radius={[0, 4, 4, 0]} name="Contribution %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
