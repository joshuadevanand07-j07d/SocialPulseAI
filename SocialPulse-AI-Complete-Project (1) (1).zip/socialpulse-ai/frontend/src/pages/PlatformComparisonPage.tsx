import React, { useEffect, useState } from 'react';
import {
  Globe,
  TrendingUp,
  Percent,
  Eye,
  Heart,
  Share2,
  Bookmark,
  MessageCircle,
  PlaySquare,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';
import { FilterState, PlatformStat } from '../types';
import { api } from '../services/api';
import { PlatformBadge } from '../components/Badges';

interface PlatformComparisonPageProps {
  filters: FilterState;
}

export const PlatformComparisonPage: React.FC<PlatformComparisonPageProps> = ({
  filters,
}) => {
  const [platforms, setPlatforms] = useState<PlatformStat[]>([]);
  const [totalPosts, setTotalPosts] = useState<number>(0);
  const [summaryNotes, setSummaryNotes] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    api.getPlatformComparison(filters)
      .then((res) => {
        if (mounted) {
          setPlatforms(res.platforms);
          setTotalPosts(res.total_posts);
          setSummaryNotes(res.summary_notes);
        }
      })
      .catch((err) => console.error(err))
      .finally(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [filters]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center space-y-3 text-slate-400">
          <div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-medium">Aggregating cross-platform comparative metrics...</p>
        </div>
      </div>
    );
  }

  // Normalization for Radar Chart comparison (0-100 scale)
  const maxReach = Math.max(...platforms.map((p) => p.avg_reach), 1);
  const maxER = Math.max(...platforms.map((p) => p.median_engagement_rate), 1);
  const maxCTR = Math.max(...platforms.map((p) => p.avg_ctr), 1);
  const maxInteractions = Math.max(
    ...platforms.map((p) => (p.total_likes + p.total_comments + p.total_shares + p.total_saves) / Math.max(p.post_count, 1)),
    1
  );

  const radarData = [
    { subject: 'Median ER%', ...Object.fromEntries(platforms.map((p) => [p.platform, Math.round((p.median_engagement_rate / maxER) * 100)])) },
    { subject: 'Mean ER%', ...Object.fromEntries(platforms.map((p) => [p.platform, Math.round((p.avg_engagement_rate / maxER) * 100)])) },
    { subject: 'Avg CTR%', ...Object.fromEntries(platforms.map((p) => [p.platform, Math.round((p.avg_ctr / maxCTR) * 100)])) },
    { subject: 'Avg Reach', ...Object.fromEntries(platforms.map((p) => [p.platform, Math.round((p.avg_reach / maxReach) * 100)])) },
    { subject: 'Interactions/Post', ...Object.fromEntries(platforms.map((p) => [p.platform, Math.round((((p.total_likes + p.total_comments + p.total_shares + p.total_saves) / p.post_count) / maxInteractions) * 100)])) },
  ];

  const PLATFORM_COLORS: Record<string, string> = {
    Facebook: '#3B82F6',
    Instagram: '#EC4899',
    X: '#94A3B8',
    LinkedIn: '#0284C7',
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Title & Notes */}
      <div className="bg-[#111827] p-5 rounded-xl border border-[#1e293b] shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <Globe className="w-5 h-5 text-violet-400" />
              <span>Multi-Platform Performance Comparison</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Comparative analysis across {platforms.length} platforms from {totalPosts} posts.
            </p>
          </div>
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>Consistent Reach-Based Metric Definitions</span>
          </div>
        </div>

        {summaryNotes.length > 0 && (
          <div className="mt-4 pt-3 border-t border-[#1e293b] space-y-1.5">
            <p className="text-[11px] font-semibold text-violet-300 uppercase tracking-wider flex items-center space-x-1.5">
              <Info className="w-3.5 h-3.5" />
              <span>Data-Driven Comparison Summary</span>
            </p>
            {summaryNotes.map((note, idx) => (
              <p key={idx} className="text-xs text-slate-300 leading-relaxed">
                • {note}
              </p>
            ))}
          </div>
        )}
      </div>

      {/* Platform Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {platforms.map((p) => (
          <div
            key={p.platform}
            className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md space-y-3"
          >
            <div className="flex items-center justify-between">
              <PlatformBadge platform={p.platform} />
              <span className="text-xs text-slate-400 font-medium">
                {p.post_count} posts ({p.post_share_pct}%)
              </span>
            </div>

            <div>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-bold text-white">
                  {p.median_engagement_rate}%
                </span>
                <span className="text-xs text-slate-400">median ER</span>
              </div>
              <span className="text-xs text-slate-500">
                Mean: {p.avg_engagement_rate}% • CTR: {p.avg_ctr}%
              </span>
            </div>

            <div className="pt-3 border-t border-[#1e293b] space-y-1.5 text-xs text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Reach:</span>
                <span className="font-semibold">{p.total_reach.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Impressions:</span>
                <span className="font-semibold">{p.total_impressions.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Likes:</span>
                <span>{p.total_likes.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Video Views:</span>
                <span>{p.total_video_views.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Top Format:</span>
                <span className="text-violet-400 font-medium">{p.top_post_type}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Comparison Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Engagement Rate Comparison Grouped Bar */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
          <h3 className="text-sm font-semibold text-white">Engagement Rate & CTR Benchmarks</h3>
          <p className="text-xs text-slate-400 mb-4">Comparing median ER against CTR across platforms</p>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={platforms} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="platform" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="median_engagement_rate" fill="#8B5CF6" name="Median ER %" radius={[4, 4, 0, 0]} />
                <Bar dataKey="avg_ctr" fill="#06B6D4" name="Avg CTR %" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Normalized Relative Radar Profile */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] shadow-md">
          <h3 className="text-sm font-semibold text-white">Platform Performance Profile (Normalized)</h3>
          <p className="text-xs text-slate-400 mb-4">Relative index across reach, efficiency, and engagement</p>

          <div className="h-72 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#263554" />
                <PolarAngleAxis dataKey="subject" stroke="#94a3b8" fontSize={11} />
                <PolarRadiusAxis stroke="#475569" angle={30} domain={[0, 100]} fontSize={10} />
                {platforms.map((p) => (
                  <Radar
                    key={p.platform}
                    name={p.platform}
                    dataKey={p.platform}
                    stroke={PLATFORM_COLORS[p.platform] || '#8B5CF6'}
                    fill={PLATFORM_COLORS[p.platform] || '#8B5CF6'}
                    fillOpacity={0.2}
                  />
                ))}
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e1424', borderColor: '#263554', borderRadius: '8px', color: '#f1f5f9', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
