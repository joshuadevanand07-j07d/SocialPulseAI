# SocialPulse AI – Social Media Engagement Analytics & Prediction

> **A professional, end-to-end analytics and machine learning web application for exploring historical social-media performance, benchmarking cross-platform metrics, and predicting post engagement without target leakage.**

---

## 🌟 Key Features

1. **Executive Overview Dashboard**
   - High-level KPIs: Total Posts, Total Interactions (Likes, Comments, Shares, Saves), Total Reach & Impressions, Average & Median Engagement Rate (ER%), Average & Median Click-Through Rate (CTR%), Total Video Views, and Flagged Anomaly Count.
   - Interactive Recharts:
     - **Engagement Over Time**: Dynamic time-series area chart tracking daily rates and interactions.
     - **Platform Benchmarks**: Grouped bar chart comparing Mean ER% vs. Median ER% to highlight statistical skew.
     - **Content Format Breakdown**: Ranked median engagement across Carousels, Images, Videos, Reels, and Text.
     - **Audience Sentiment Mix**: Donut chart displaying Positive, Neutral, and Negative response proportions.
     - **Interactions Composition**: Stacked bar chart showing relative shares of Likes, Comments, Shares, and Saves per platform.
     - **Distributions**: Frequency histograms for Engagement Rate % and CTR %.
     - **Top Performing Posts**: Interactive summary table with direct navigation to post deep-dives.

2. **Historical Data Explorer**
   - Searchable (by Post ID, platform, post type, sentiment), sortable across all columns, and paginated (10, 15, 25, 50, 100 rows per page).
   - Real-time multi-dimensional filters: Platform, Post Type, Sentiment, Date Range (Start/End).
   - **Robust View / Outlier Toggle**: Easily toggle between raw data and filtered views excluding high-ER outliers (>100%).
   - Direct CSV export of currently filtered view.
   - Excel (.xlsx) file upload modal with instant schema validation and error feedback without overwriting the original file.

3. **Platform Comparison Page**
   - Comparative evaluation across Facebook, Instagram, LinkedIn, and X (formerly Twitter).
   - Key metrics: Median & Mean ER%, CTR%, Total & Avg Reach, Total & Avg Impressions, Total Video Views, and Share of Total Posts.
   - **Normalized Relative Radar Profile**: Multi-axis radar chart showing platform strengths across reach, efficiency, and engagement.
   - Data-grounded, conservative comparative observations with non-causal language.

4. **Post Performance Deep-Dive**
   - Detailed inspection card for any Post ID (e.g. `P001` through `P300`).
   - Benchmark gauges comparing the post's metrics against the **Platform Median** and the **Global Overall Median**.
   - Transparent performance tiers: **Top 10% (Elite Performer)**, **Above Average**, **Average / Typical**, and **Underperforming**.
   - Contextual commentary explaining the underlying factors (e.g., high viral share ratio vs. recorded reach).

5. **Machine Learning Engagement Predictor**
   - Pre-publication parameter simulation:
     - Select Platform, Post Type, Tone / Sentiment.
     - Adjust Followers, Expected Reach, Expected Impressions, Video Views, and Hashtag Count via responsive sliders and inputs.
   - **Zero Target Leakage**: Post-publication outcomes (actual likes, comments, shares, saves, or CTR) are strictly excluded from feature inputs.
   - Predicts **Engagement Rate %** with a confidence interval range and computes **Estimated Total Engagements** `(ER% × Reach) / 100`.
   - **Model Transparency & Evaluation**:
     - Baseline comparison against `DummyRegressor(strategy='mean')`.
     - Compared models: `Ridge Regression`, `HistGradientBoostingRegressor`, and `RandomForestRegressor`.
     - Evaluation metrics reported on an 80/20 held-out test split (60 unseen records) and 5-fold cross-validation on training data.
     - Feature relative importance chart showing the exact drivers of the prediction.
     - Transparent small-dataset reliability warnings.

6. **Insights & Recommendations**
   - Data-grounded automated observations across Platform, Content Format, Hashtag Count correlation, Audience Sentiment, and Outlier patterns.
   - Each insight includes observed sample size ($n$) and confidence level.
   - Strictly non-causal phrasing adhering to scientific standards.

7. **Data Quality & Audit**
   - Mathematical formula verification confirming that $ER\% = \frac{\text{Likes} + \text{Comments} + \text{Shares} + \text{Saves}}{\text{Reach}} \times 100$ ($r > 0.99999$).
   - Schema validation showing 0 missing values, 0 duplicate IDs, and 0 negative values.
   - Transparent analysis of records with $ER\% > 100\%$ where interactions exceed unique Reach.

8. **Downloads & Reports**
   - **Executive PDF Report**: Built via ReportLab with professional typography, active filters, KPI matrix, platform table, ML benchmarks, and data quality notes.
   - **Filtered Records (CSV)**: Generated on the fly from current active filters.
   - **Cleaned Dataset (CSV)**: Export with extreme outliers filtered out for sensitivity modeling.
   - **Original Excel (.xlsx)**: Direct download of the supplied original dataset.
   - **Printable Layout**: Clean browser print stylesheet.

9. **About & Methodology**
   - Complete documentation of data provenance, exact mathematical formulas, and ML training protocol.
   - Explicit disclaimer that this application analyzes historical benchmark data and does not stream real-time feeds.

---

## 🏗️ Project Architecture

```
socialpulse-ai/
├── backend/
│   ├── data/
│   │   ├── Social_Media_Engagement_Analysis_Dataset_300.xlsx     # Preserved original dataset
│   │   ├── Social_Media_Engagement_Analysis_Dataset_300(1).xlsx  # Alias copy
│   │   └── Social_Media_Engagement_Analysis_Dataset_300.csv     # CSV representation
│   ├── tests/
│   │   ├── test_data_loader.py   # Unit tests for loading, filtering, & KPIs
│   │   ├── test_ml.py            # Unit tests for ML pipeline, baseline, & prediction
│   │   └── test_api.py           # Integration tests for FastAPI endpoints
│   ├── data_loader.py            # Data loading, cleaning policy, and calculations
│   ├── ml_pipeline.py            # Scikit-learn pipelines, CV, models, & prediction
│   ├── models.py                 # Pydantic v2 schemas and request/response models
│   ├── report_generator.py       # ReportLab PDF report generation
│   ├── main.py                   # FastAPI server, endpoints, and CORS
│   └── requirements.txt          # Python dependencies
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Badges.tsx        # Platform, sentiment, and anomaly badges
│   │   │   ├── FilterBar.tsx     # Global responsive filter bar
│   │   │   ├── Header.tsx        # Top toolbar with dataset badge & actions
│   │   │   ├── MetricCard.tsx    # Reusable KPI card with tooltips
│   │   │   ├── Sidebar.tsx       # Collapsible navigation sidebar
│   │   │   └── UploadModal.tsx   # Drag-and-drop Excel/CSV upload modal
│   │   ├── pages/
│   │   │   ├── AboutPage.tsx
│   │   │   ├── DashboardPage.tsx
│   │   │   ├── DataExplorerPage.tsx
│   │   │   ├── DataQualityPage.tsx
│   │   │   ├── DownloadsPage.tsx
│   │   │   ├── InsightsPage.tsx
│   │   │   ├── PlatformComparisonPage.tsx
│   │   │   ├── PostPerformancePage.tsx
│   │   │   └── PredictionPage.tsx
│   │   ├── services/
│   │   │   └── api.ts            # API client service
│   │   ├── types/
│   │   │   └── index.ts          # TypeScript type definitions
│   │   ├── App.tsx               # Root application component
│   │   ├── index.css             # Tailwind v4 theme styling
│   │   └── main.tsx              # React DOM entrypoint
│   ├── index.html                # HTML template with fonts and metadata
│   ├── package.json              # Node.js dependencies
│   ├── tsconfig.json             # TypeScript configuration
│   └── vite.config.ts            # Vite configuration with Tailwind & API proxy
├── .env.example                  # Environment template
└── README.md                     # Documentation
```

---

## 🚀 Quick Start Guide

### Prerequisites
- **Python**: Version 3.10+ (tested on Python 3.14 / 3.12)
- **Node.js**: Version 18+ (tested on Node v22)
- **Package Managers**: `pip` and `npm`

---

### 1. Backend Setup & Run

#### On Windows (PowerShell):
```powershell
# Navigate to the backend directory
cd "C:\Users\Joshua Daniel\.gemini\antigravity\scratch\socialpulse-ai\backend"

# Install dependencies
python -m pip install -r requirements.txt

# Run the test suite
python -m pytest tests -v

# Start the FastAPI server
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

#### On macOS / Linux:
```bash
cd backend
python3 -m pip install -r requirements.txt
python3 -m pytest tests -v
python3 -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

Backend will be accessible at:
- **API Root**: [http://127.0.0.1:8000](http://127.0.0.1:8000)
- **Swagger OpenAPI Docs**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- **ReDoc**: [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

---

### 2. Frontend Setup & Run

#### On Windows (PowerShell):
```powershell
# Navigate to the frontend directory
cd "C:\Users\Joshua Daniel\.gemini\antigravity\scratch\socialpulse-ai\frontend"

# Install dependencies (if not already installed)
npm.cmd install

# Start the Vite development server
npm.cmd run dev
```

#### On macOS / Linux:
```bash
cd frontend
npm install
npm run dev
```

Frontend will be accessible at:
- **Web Application URL**: [http://localhost:5173](http://localhost:5173)

---

## 🧪 Testing and Verification Results

The test suite contains **16 comprehensive unit and integration tests** covering the data loader, machine learning pipeline, and API endpoints:

```
tests/test_api.py::test_health PASSED
tests/test_api.py::test_dataset_info PASSED
tests/test_api.py::test_summary PASSED
tests/test_api.py::test_posts_pagination_and_search PASSED
tests/test_api.py::test_post_detail PASSED
tests/test_api.py::test_predict_endpoint PASSED
tests/test_api.py::test_model_metrics_endpoint PASSED
tests/test_api.py::test_data_quality_endpoint PASSED
tests/test_api.py::test_export_csv PASSED
tests/test_api.py::test_export_pdf PASSED
tests/test_data_loader.py::test_data_loader_initialization PASSED
tests/test_data_loader.py::test_kpi_calculations PASSED
tests/test_data_loader.py::test_filtering PASSED
tests/test_data_loader.py::test_post_detail_benchmark PASSED
tests/test_ml.py::test_ml_pipeline_training PASSED
tests/test_ml.py::test_ml_pipeline_prediction PASSED

======================= 16 passed in 21.50s =======================
```

---

## 🤖 Machine Learning Model Benchmarks

Evaluation performed on a **20% held-out test split (60 unseen posts)** with 5-fold cross-validation on the 240 training posts:

| Model Name | Type | Test MAE | Test RMSE | Test R² | 5-Fold CV R² (Mean ± Std) |
|---|---|---|---|---|---|
| **Dummy Regressor** | Baseline | 71.86 | 116.06 | -0.009 | -0.024 ± 0.018 |
| **Ridge Regression** | Linear | 52.35 | 95.97 | 0.310 | 0.284 ± 0.061 |
| **HistGradientBoosting** | Tree Ensemble | 29.96 | 58.17 | 0.746 | 0.712 ± 0.054 |
| **Random Forest Regressor** | Tree Ensemble (Champion) | **28.78** | **56.37** | **0.762** | **0.738 ± 0.048** |

### Feature Importances (Random Forest):
- **Unique Reach**: 48.2%
- **Impressions**: 24.6%
- **Platform**: 13.5%
- **Followers**: 8.4%
- **Post Type**: 3.7%
- **Hashtags & Sentiment**: 1.6%

---

## 📡 Example API Requests

### 1. Health Check
```bash
curl -X GET http://127.0.0.1:8000/api/health
```

### 2. KPI Summary with Filters
```bash
curl -X GET "http://127.0.0.1:8000/api/summary?platform=Instagram&post_type=Carousel"
```

### 3. ML Post Engagement Prediction
```bash
curl -X POST http://127.0.0.1:8000/api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "platform": "Instagram",
    "post_type": "Video",
    "sentiment": "Positive",
    "followers": 75000,
    "impressions": 25000,
    "reach": 12000,
    "video_views": 15000,
    "hashtag_count": 6
  }'
```

### 4. Download Executive PDF Report
```bash
curl -X GET "http://127.0.0.1:8000/api/export/pdf" --output Executive_Report.pdf
```

---

## 🔧 Troubleshooting

- **PowerShell Execution Policy Error**: If `npm` gives an execution policy error on Windows, execute using `npm.cmd` instead of `npm`.
- **CORS Errors**: The backend is configured to allow origins `http://localhost:5173` and `http://127.0.0.1:5173`. If running on a different port, update `ALLOWED_ORIGINS` in `main.py` or `.env`.
- **Custom Upload Reset**: If an uploaded dataset produces unexpected behavior, click the **"Reset to Default"** button in the header or call `POST /api/reset` to instantly reload the verified 300-record dataset.

---

## 📄 License & Attribution

Built for the Google Antigravity pair programming workspace. Powered by React, Vite, Tailwind CSS, FastAPI, and Scikit-Learn.
