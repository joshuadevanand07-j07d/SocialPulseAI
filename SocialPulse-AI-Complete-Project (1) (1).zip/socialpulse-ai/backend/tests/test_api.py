import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health():
    res = client.get("/api/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"
    assert data["total_rows"] == 300

def test_dataset_info():
    res = client.get("/api/dataset-info")
    assert res.status_code == 200
    data = res.json()
    assert data["total_records"] == 300
    assert "Facebook" in data["platforms"]

def test_summary():
    res = client.get("/api/summary")
    assert res.status_code == 200
    data = res.json()
    assert "kpis" in data
    assert data["kpis"]["total_posts"] == 300
    assert len(data["platforms"]) > 0

def test_posts_pagination_and_search():
    res = client.get("/api/posts?page=1&page_size=10")
    assert res.status_code == 200
    data = res.json()
    assert len(data["items"]) == 10
    assert data["total"] == 300

    # Search
    search_res = client.get("/api/posts?search=P001")
    assert search_res.status_code == 200
    search_data = search_res.json()
    assert any(item["Post_ID"] == "P001" for item in search_data["items"])

def test_post_detail():
    res = client.get("/api/posts/P001")
    assert res.status_code == 200
    data = res.json()
    assert data["post"]["Post_ID"] == "P001"
    assert "platform_median_er" in data

def test_predict_endpoint():
    payload = {
        "platform": "Instagram",
        "post_type": "Image",
        "sentiment": "Neutral",
        "followers": 50000,
        "impressions": 20000,
        "reach": 10000,
        "video_views": 15000,
        "hashtag_count": 5
    }
    res = client.post("/api/predict", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert "predicted_engagement_rate_pct" in data
    assert data["predicted_engagement_rate_pct"] > 0
    assert "estimated_engagement_count" in data

def test_model_metrics_endpoint():
    res = client.get("/api/model-metrics")
    assert res.status_code == 200
    data = res.json()
    assert len(data["models"]) >= 3
    assert data["target_variable"] == "Engagement_Rate_%"

def test_data_quality_endpoint():
    res = client.get("/api/data-quality")
    assert res.status_code == 200
    data = res.json()
    assert data["total_rows"] == 300
    assert data["missing_values_by_column"]["Post_ID"] == 0

def test_export_csv():
    res = client.get("/api/export/csv")
    assert res.status_code == 200
    assert "text/csv" in res.headers["content-type"]
    assert "Post_ID,Platform" in res.text

def test_export_pdf():
    res = client.get("/api/export/pdf")
    assert res.status_code == 200
    assert "application/pdf" in res.headers["content-type"]
    assert len(res.content) > 1000
