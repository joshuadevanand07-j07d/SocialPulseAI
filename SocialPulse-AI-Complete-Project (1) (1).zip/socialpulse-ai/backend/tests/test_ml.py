import pytest
from data_loader import DataLoader
from ml_pipeline import MLPipeline

def test_ml_pipeline_training():
    loader = DataLoader()
    pipeline = MLPipeline()
    pipeline.train_and_evaluate(loader.df_processed)

    assert pipeline.is_trained
    assert pipeline.train_size == 240
    assert pipeline.test_size == 60
    assert len(pipeline.metrics_summary) >= 3

    # Check baseline presence
    dummy_metric = next((m for m in pipeline.metrics_summary if m['is_baseline']), None)
    assert dummy_metric is not None

    # Check best model is identified
    assert pipeline.best_model_name in pipeline.trained_models

def test_ml_pipeline_prediction():
    loader = DataLoader()
    pipeline = MLPipeline()
    pipeline.train_and_evaluate(loader.df_processed)

    test_input = {
        "platform": "Instagram",
        "post_type": "Video",
        "sentiment": "Positive",
        "followers": 75000,
        "impressions": 25000,
        "reach": 12000,
        "video_views": 30000,
        "hashtag_count": 6
    }

    result = pipeline.predict(test_input)
    assert "predicted_engagement_rate_pct" in result
    assert result["predicted_engagement_rate_pct"] > 0
    assert "estimated_engagement_count" in result
    assert result["estimated_engagement_count"] >= 0
    assert "confidence_interval" in result
    assert "baseline_predicted_er_pct" in result
