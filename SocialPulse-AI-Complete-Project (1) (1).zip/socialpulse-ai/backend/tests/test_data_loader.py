import pytest
import os
import pandas as pd
from data_loader import DataLoader, REQUIRED_COLUMNS

def test_data_loader_initialization():
    loader = DataLoader()
    assert len(loader.df_processed) == 300
    assert not loader.df_processed.empty
    for col in REQUIRED_COLUMNS:
        assert col in loader.df_processed.columns

def test_kpi_calculations():
    loader = DataLoader()
    kpis = loader.get_kpis(loader.df_processed)
    assert kpis['total_posts'] == 300
    assert kpis['total_likes'] > 0
    assert kpis['total_reach'] > 0
    assert kpis['avg_engagement_rate'] > 0
    assert kpis['platform_count'] == 4

def test_filtering():
    loader = DataLoader()
    # Filter by Facebook
    fb_df = loader.filter_df(platform="Facebook")
    assert not fb_df.empty
    assert (fb_df['Platform'] == "Facebook").all()

    # Filter with exclude_outliers
    robust_df = loader.filter_df(exclude_outliers=True)
    assert len(robust_df) < 300
    assert (robust_df['Engagement_Rate_%'] <= 100.0).all()

def test_post_detail_benchmark():
    loader = DataLoader()
    detail = loader.get_post_detail("P001")
    assert detail is not None
    assert detail['post']['Post_ID'] == "P001"
    assert "platform_median_er" in detail
    assert "performance_tier" in detail
